#ifndef SEPARATION_TASK_H
#define SEPARATION_TASK_H

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Simple struct for storing a separation task, containing the source node, i.e. the node for
 * 			which the separation procedure shall be executed, a flag whether it is an aggregation node,
 * 			and a cutoff value. If a flow of the source towards the super sink receiver of more or equal
 * 			to cutoff exists, then there does not exist a violated inequality.
 */
struct SeparationTask{
	int source;
	bool isAggregationNode;
	int cutoff;
};

#endif
