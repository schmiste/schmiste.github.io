/**
 * @file 	main.cpp
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Main routine of the CVSAP-solver, receives as single input the name of a CVSAP-instance file
 * 			and reads parameters placed in cvsap.set which must be placed in the working directory and then
 * 			solves the problem.
 * 			After having solved the problem, a VA according to the IP solution is constructed.
 */

// standard library includes
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

// scip includes
#include "objscip/objscip.h"
#include "objscip/objscipdefplugins.h"
#include "scip/paramset.h"
#include "scip/type_paramset.h"
#include "scip/set.h"
#include "scip/nodesel_hybridestim.h"

// example includes
#include "ConnectivityConstraintHandler.h"
#include "CVSAPData.h"
#include "ReceiverConfiguration.h"
#include "DecomposeFlow.h"
#include "VA.h"
#include "HeurFlowDecompositionRounding.h"

// namespace usage 
using namespace std;
using namespace scip;


/**
 *	Debugging Method for outputting a solution and some meta data
 */
void writeSolution( SCIP* scip, SCIP_SOL* sol, const Digraph& g, const CVSAPData* data)
{
	string name;
	name = data->getScenarioName() + string(".sol");
	cout << "Writing solution file " << name << endl;
	ofstream file;
	file.open(name.c_str());
	for (int e = 0; e < g.num_edges(); ++e) {
		const double x = SCIPgetSolVal(scip, sol, data->arc_var(e));
		file << "f(" << g.get_node_name(g.src_node(e)) << ","
				<< g.get_node_name(g.tgt_node(e)) << ") " << x << endl;
	}
	for (vector<int>::const_iterator aggIt =
			data->get_aggregation_nodes().begin();
			aggIt != data->get_aggregation_nodes().end(); ++aggIt) {
		file << "chi_A(" << g.get_node_name(*aggIt) << ") "
				<< SCIPgetSolVal(scip, sol, data->get_chi_A(*aggIt))
				<< endl;
	}
	for (unsigned int i = 0;
			i < data->getReceiverConfigurations().size(); ++i) {
		const ReceiverConfiguration& rcvConf =
				data->getReceiverConfiguration(i);
		file << "chi_R(" << rcvConf.get_name() << ") "
				<< SCIPgetSolVal(scip, sol, data->get_chi_R(i)) << endl;
	}
	file.close();
	name = data->getScenarioName() + string(".meta");
	cout << "Writing meta solution file " << name << endl;
	SCIP_SOL* const bestSol = SCIPgetBestSol(scip);
	file.open(name.c_str());
	file << "runtime " << SCIPgetSolvingTime(scip) << endl;
	file << "iteration_count " << SCIPgetNLPIterations(scip) << endl;
	file << "node_count " << SCIPgetNNodes(scip) << endl;
	file << "is_optimum " << (SCIPgetGap(scip) < 0.01) << endl;
	if (!SCIPisInfinity(scip, SCIPgetGap(scip))) {
		file << "gap " << SCIPgetGap(scip) << endl;
	} else {
		file << "gap -1" << endl;
	}
	if (sol != NULL) {
		file << "objective_value " << SCIPgetSolOrigObj(scip, bestSol)
				<< endl;
	} else {
		file << "objective_value -1 " << endl;
	}
	if (!SCIPisInfinity(scip, SCIPgetDualbound(scip))) {
		file << "best_bound " << SCIPgetDualbound(scip) << endl;
	} else {
		file << "best_bound -1" << endl;
	}
	file << "solution_count " << SCIPgetNSolsFound(scip) << endl;
}

//------------------------------------------------------------
//------------------------------------------------------------
int main(int argc, char** argv) {
	SCIP* scip = NULL;

	cout << endl;

	if (argc != 2 && argc != 3) {
		cerr << "Usage: cvsap datafile" << endl;
		return 1;
	}

	/**************
	 * Init SCIP *
	 **************/

	/* initialize SCIP environment */
	SCIP_CALL(SCIPcreate(&scip));

	/***********************
	 * Version information *
	 ***********************/
	SCIPprintVersion(scip, NULL);

	/***********************
	 * Add Parameters *
	 ***********************/

	SCIP_CALL( SCIPaddIntParam(scip,
			"constraints/Connectivity/number_of_threads_for_flow_calculation",
			"determines the number of threads to be used for calculation of flows",
			NULL, FALSE, 2, 1, 16, NULL, NULL) );

	SCIP_CALL( SCIPaddIntParam(scip,
			"constraints/Connectivity/scale",
			"scale for rounding fractional flows",
			NULL, FALSE, 1000, 1, 100000, NULL, NULL) );

	SCIP_CALL( SCIPaddIntParam(scip,
			"constraints/Connectivity/nest_depth",
			"gives the maximal depth for searching for nested cuts; 0 disables nested cuts",
			NULL, FALSE, 0, 0, 100000, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"constraints/Connectivity/creep",
			"determines whether creep flow shall be used",
			NULL, FALSE, TRUE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"constraints/Connectivity/separateTerminals",
			"determines whether cuts for terminals shall be created",
			NULL, FALSE, TRUE, NULL, NULL) );

	SCIP_CALL( SCIPaddIntParam(scip,
			"constraints/Connectivity/max_number_of_cuts_before_lp_recalculation",
			"enforce LP recalculation after this number of newly found cuts",
			NULL, FALSE, 10000, 0, 10000, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"constraints/Connectivity/add_sender_cuts_to_global_pool",
			"determines whether the generated cuts from the senders shall be placed in the global cut pool",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"constraints/Connectivity/add_aggregation_cuts_to_global_pool",
			"determines whether the generated cuts from the aggregation nodes shall be placed in the global cut pool",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddRealParam(scip,
			"constraints/Connectivity/threshold_of_absorbed_flow_to_start_aggregation_cuts",
			"determines the threshold of incoming flow after which (fractionally) activated",
			NULL, FALSE, 100, 0, 10000, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"aggregation_mip/integral_flow",
			"determines whether the flow variables are restricted to integers",
			NULL, FALSE, TRUE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"aggregation_mip/debug/threading",
			"determines whether debug outputs of the threading process shall be output",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"aggregation_mip/debug/model_construction",
			"determines whether debug outputs of the model construction shall be output",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"aggregation_mip/debug/ConnectivityHandler",
			"determines whether debug outputs of the Steiner Cut Handler shall be output",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"aggregation_mip/debug/connectivity_heuristic",
			"determines whether debug outputs of the connectivity heuristics shall be output",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddBoolParam(scip,
			"aggregation_mip/debug/FlowDecoRound",
			"determines whether debug outputs of the flow decomposition rounding heuristic shall be output",
			NULL, FALSE, FALSE, NULL, NULL) );

	SCIP_CALL( SCIPaddIntParam(scip,
			"heuristics/FlowDecoRound/max_iterations_solution_polishing",
			"maximal number of rounds to perform solution polishing",
			NULL, FALSE, 1000, 0, 1000000, NULL, NULL) );



	/* create empty problem */
	SCIP_CALL(SCIPcreateProb(scip, "CVSAP", 0, 0, 0, 0, 0, 0, 0));

	/* include default plugins */
	SCIP_CALL(SCIPincludeDefaultPlugins(scip));

	SCIP_ParamEmphasis emphasis = SCIP_PARAMEMPHASIS_OPTIMALITY;

	SCIPsetEmphasis(scip, emphasis, FALSE);


	/********************
	 * Read Parameters	*
	 *******************/

	/* read parameters */
	SCIP_CALL(SCIPreadParams(scip, "cvsap.set"));

	//set parameters

	double aggregationAbsorptionThreshold;

	int SCALE, nestDepth, maxNumberOfCutsBeforeRecalculation, numberOfThreads, maxNumberOfIterationsSolutionPolishing;

	SCIP_Bool useCreep, separateTerminals, addCutsToPoolSender, addCutsToPoolAggregationNodes, integralFlow, debug_threading, debug_model_construction, debug_Connectivity_handler, debug_connectivity_heuristic, debug_heuristic_flowdecoround;

	SCIP_CALL(SCIPgetIntParam(scip, "constraints/Connectivity/scale", &SCALE));

	SCIP_CALL(SCIPgetIntParam(scip, "constraints/Connectivity/number_of_threads_for_flow_calculation", &numberOfThreads));

	SCIP_CALL(
			SCIPgetIntParam(scip, "constraints/Connectivity/nest_depth",
					&nestDepth));

	SCIP_CALL(
			SCIPgetBoolParam(scip, "constraints/Connectivity/separateTerminals",
					&separateTerminals));


	SCIP_CALL(SCIPgetBoolParam(scip, "constraints/Connectivity/creep", &useCreep));

	SCIP_CALL(SCIPgetBoolParam(scip, "aggregation_mip/integral_flow", &integralFlow));

	SCIP_CALL(SCIPgetIntParam(scip, "constraints/Connectivity/max_number_of_cuts_before_lp_recalculation",
					&maxNumberOfCutsBeforeRecalculation));


	SCIP_CALL(SCIPgetBoolParam(scip, "constraints/Connectivity/add_aggregation_cuts_to_global_pool", &addCutsToPoolAggregationNodes));

	SCIP_CALL(SCIPgetBoolParam(scip, "constraints/Connectivity/add_sender_cuts_to_global_pool", &addCutsToPoolSender));

	SCIP_CALL( SCIPgetRealParam(scip, "constraints/Connectivity/threshold_of_absorbed_flow_to_start_aggregation_cuts", &aggregationAbsorptionThreshold));


	SCIP_CALL(SCIPgetBoolParam(scip, "aggregation_mip/debug/threading", &debug_threading));

	SCIP_CALL(SCIPgetBoolParam(scip, "aggregation_mip/debug/model_construction", &debug_model_construction));

	SCIP_CALL(SCIPgetBoolParam(scip, "aggregation_mip/debug/ConnectivityHandler", &debug_Connectivity_handler));

	SCIP_CALL(SCIPgetBoolParam(scip, "aggregation_mip/debug/connectivity_heuristic", &debug_connectivity_heuristic));

	SCIP_CALL(SCIPgetBoolParam(scip, "aggregation_mip/debug/FlowDecoRound", &debug_heuristic_flowdecoround));

	SCIP_CALL(
				SCIPgetIntParam(scip, "heuristics/FlowDecoRound/max_iterations_solution_polishing",
						&maxNumberOfIterationsSolutionPolishing));



	Parameters parameters(	SCALE,
							nestDepth,
							useCreep,
							separateTerminals,
							maxNumberOfCutsBeforeRecalculation,
							addCutsToPoolSender,
							addCutsToPoolAggregationNodes,
							aggregationAbsorptionThreshold,
							numberOfThreads,
							integralFlow,
							debug_threading,
							debug_model_construction,
							debug_Connectivity_handler,
							debug_connectivity_heuristic,
							debug_heuristic_flowdecoround,
							maxNumberOfIterationsSolutionPolishing);

	/*************
	 * Read Data *
	 *************/
	CVSAPData data;

	data.setParameters(&parameters);

	if (data.read(argv[argc - 1])) {
		cerr << "Error reading data file " << argv[argc - 1] << endl;
		return 1;
	}

	cout << "Read " << data.graph().num_edges() << " edges and "
			<< data.graph().num_nodes() << " nodes and "
			<< data.get_senders().size() << " senders and "
			<< data.get_aggregation_nodes().size() << " possible aggregation nodes "
			<< data.getReceiverConfigurations().size() << " different receiver configurations." << endl;


	/**********************
	 * Include Heuristic  *
	 **********************/

	SCIP_CALL(SCIPincludeHeurFlowDecompositionRounding(scip, &data));

	/**********************
	 * Create Variables   *
	 **********************/

	data.createVariables(scip);


	/*******************************************
	 * Include Connectivity Inequality Handler *
	 *******************************************/

	SCIP_CALL(SCIPincludeObjConshdlr(scip, new ConnectivityConstraintHandler(scip),
					TRUE));

	SCIP_CONS* con;
	SCIP_CALL(
			SCIPcreateConnectivityConstraint(scip, &con, "ConnectivityConstraints",
					&data, FALSE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE,
					FALSE));
	SCIP_CALL(SCIPaddCons(scip, con));
	SCIP_CALL(SCIPreleaseCons(scip, &con));


	/*****************************
	 * Include other Constraints *
	 *****************************/

	data.includeConstraint_FlowPreservationAtNodes(scip);
	data.includeConstraint_SetFlowFromSuperSourceToAggregationNode(scip);
	data.includeConstraint_ActivatedAggregationNodesForwardFlow(scip);
	data.includeConstraint_CapacityIsNotViolatedReceiver(scip);
	data.includeConstraint_CapacityIsNotViolatedAggregationNode(scip);
	data.includeConstraint_BoundAllowedNumberOfReceiverConfiguration(scip);
	data.includeConstraint_BoundCostsForInstallingAggregationNodes(scip);


	/**********************************************
	 * Create Threadpool for Separation procedure *
	 **********************************************/

	data.createThreadPool(scip);

	/*************
	 Solve:		 *
	 *************/
	SCIP_CALL(SCIPsolve(scip));




	/*************
	 Statistics: *
	 *************/
	SCIP_CALL( SCIPprintStatistics(scip, NULL) );
	cout << "---------------------------------------------\n";
	cout << "	 	RAW SOLUTION VALUES	\n";
	cout << "---------------------------------------------\n";

	/*************
	 Solution: *
	 *************/

	writeSolution(scip, SCIPgetBestSol(scip), data.graph(), &data);

	SCIP_CALL( SCIPprintBestSol(scip, NULL, FALSE) );
	cout << "---------------------------------------------\n";
	cout << "	 	END OF RAW SOLUTION VALUES	\n";
	cout << "---------------------------------------------\n";

	/*************************
	 * Decompose IP Solution *
	 *************************/

	IPSolutionDecomposeFlow solutionDecomposeFlow(scip, data);
	solutionDecomposeFlow.readDataFromSolution(SCIPgetBestSol(scip));
	const VA* va = solutionDecomposeFlow.constructVA();

	/**************************
	 * Output VA in text form *
	 **************************/

	string str;
	const Digraph& graph = data.graph();
	bool comma;
	cout << "";
	cout << "---------------------------------------------\n";
	cout << "	 	VA NODES	\n";
	cout << "---------------------------------------------\n";
	cout << "root=";
	cout << graph.get_node_name(va->root);
	cout << "\n";
	cout << "terminals=\n";
	for(set<int>::iterator it = va->terminals.begin(); it != va->terminals.end(); ++it)
	{
		int i = *it;
		cout << "\t\t";
		cout << graph.get_node_name(i);
		cout << "\n";
	}
	cout << "steiner nodes=\n";
	for(set<int>::iterator it = va->steinerNodes.begin(); it != va->steinerNodes.end(); ++it)
	{
		cout << "\t\t" << graph.get_node_name(*it) << "\n";
	}
	cout << "\n---------------------------------------------\n";
	cout << "		VA EDGES					\n";
	cout << "---------------------------------------------\n";

	string name;
	name = data.getScenarioName() + string(".paths");
	cout << "Writing solution file " << name << endl;
	ofstream file;
	file.open(name.c_str());
	int elemCounter = 0;
	for(map<int,int>::const_iterator it = va->vEdges.begin(); it != va->vEdges.end(); ++it)
	{
		cout << "Edge " << graph.get_node_name(it->first) << " -> ";
		cout << graph.get_node_name(it->second) << " via\n";
		const vector<int>& path = va->paths.at(it->first);
		cout << "\t";
		comma = false;
		for(vector<int>::const_iterator edgeIt = path.begin(); edgeIt != path.end(); ++edgeIt)
		{
			if(comma == true)
			{
				cout << ", ";
			}
			cout << graph.get_node_name(graph.src_node(*edgeIt)) << " -> ";
			cout << graph.get_node_name(graph.tgt_node(*edgeIt)) << " ";
			if(elemCounter == 0)
			{
				file << graph.get_node_name(graph.src_node(*edgeIt));
			}

			file << ">" << graph.get_node_name(graph.tgt_node(*edgeIt));

			if(comma == false)
			{
				comma = true;
			}
			elemCounter++;
		}
		file << endl;
		elemCounter = 0;
		cout << "\n\n";
	}
	cout << "\n---------------------------------------------\n";
	cout << "		END OF VA            					\n";
	cout << "---------------------------------------------\n";


	/********************
	 * Deinitialization *
	 ********************/
	//SCIPprintMemoryDiagnostic(scip);
	SCIPfree(&scip);
	//BMScheckEmptyMemory();

	return 0;
}
