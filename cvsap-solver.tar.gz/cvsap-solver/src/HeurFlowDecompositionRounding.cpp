/**@file   HeurFlowDecompositionRounding.cpp
 * @brief  Provides the implementation of the Flow Decomposition Rounding Heuristic for CVSAP
 * @author Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 */


#include <assert.h>
#include <iostream>
#include <dijkstra/dijkstra.h>
#include <vector>
#include <utility>
#include <algorithm>
#include <limits>
#include <deque>
#include <map>
#include <algorithm>
#include <deque>

#include <stdlib.h>

#include "HeurFlowDecompositionRounding.h"

#define HEUR_NAME             "FlowDecoRound"
#define HEUR_DESC             "Flow Decomposition Rounding"
#define HEUR_DISPCHAR         'X'
#define HEUR_PRIORITY         1000000
#define HEUR_FREQ             1
#define HEUR_FREQOFS          1
#define HEUR_MAXDEPTH         -1
#define HEUR_TIMING           SCIP_HEURTIMING_AFTERLPNODE
#define HEUR_USESSUBSCIP      FALSE  /**< does the heuristic use a secondary SCIP instance? */

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	A simple data structure representing a path with a certain amount of flow on it.
 */
struct FlowPath {
	/** amount of flow (scaled accordingly) */
	int flow;
	/** start node of this path*/
	int startNode;
	/** end node of this path*/
	int endNode;

	/** path (i.e. edges) in reversed direction*/
	vector<int>* path;

	/**determines whether the network currently allows this path
		as at least one unit of capacity is still given. */
	bool isFeasible;

	/** initialises all fields*/
	FlowPath() :
		flow(0),
		startNode(-1),
		endNode(-1),
		isFeasible(false)
	{
		this->path = new vector<int>;
	}

	/** deletes the path vector */
	void destroy()
	{
		delete path;
	}
};


/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief 	Data structure holding all variables used by this heuristic.
 */
struct SCIP_HeurData
{
	/** pointer to the solver's main data structure */
	CVSAPData* data;

	/** vector of predecessors, which is used for the search of paths */
	vector<int>* predecessor;

	/** vector of the current flow on each edge in the network*/
	vector<int>* flow;

	/** remaining capacity in the network */
	vector<int>* leftCapacity;

	/** remaining capacity in the network (before a path was selected)*/
	vector<int>* leftCapacityRollback;

	/** vector storing the predecessors changes*/
	vector<int>* changedPredecessors;

	/** index of the current path of the vector decompositionPaths in use*/
	int currentDecompositionPath;

	/** vector for storing temporary flow paths*/
	vector<FlowPath*>* decompositionPaths;

	/** set of currently opened aggregation nodes*/
	set<int>* openedAggregationNodes;

	/** set of terminals to connect*/
	vector<int>* terminals;

	/** stores virtual arcs in the current solution: maps nodes on nodes, such that (key,value)
	 * represents the virtual arc (key, value) */
	map<int, int>* virtualArcs;

	/** stores for each aggregation node / receiver the set of nodes (virtually) connected to it*/
	map<int, set<int> >* incomingVirtualArcs;

	/** stores for each terminal / aggregationn node the path used for connecting it to the node
	 * specified by virtualArcs */
	map<int, FlowPath*>* usedPathForTerminal;

	/** list of currently unconnected terminals */
	vector<int>* unconnectedTerminals;

	/** vector used in dijkstra computations */
	vector<double>* minDistance;

	/** list storing flow paths for alternative paths during cleanup*/
	vector<FlowPath*>* alternativePaths;

	/** queue used during shortest paths computations*/
	set<pair<double, int> >* dijkstraQ;

	/** queue used when trying to reduce the size of opened aggregation nodes*/
	set<pair<double, int> >* aggregationNodePriorityQ;

	/** stores a copy of the current LP solution */
	SCIP_SOL* 	sol;

	/**
	 * initializes all members
	 */
	void init()
	{
		this->flow = new vector<int>;
		for(int i = 0; i < data->graph().num_edges()+100; ++i)
		{
			this->flow->push_back(0);
		}
		this->leftCapacity = new vector<int>;
		for(int i = 0; i < data->graph().num_edges()+100; ++i)
		{
			this->leftCapacity->push_back(0);
		}
		this->leftCapacityRollback = new vector<int>;
		for(int i = 0; i < data->graph().num_edges()+100; ++i)
		{
			this->leftCapacityRollback->push_back(0);
		}
		this->predecessor = new vector<int>;
		for(int i = 0; i < data->graph().num_nodes(); ++i)
		{
			this->predecessor->push_back(-1);
		}
		this->terminals = new vector<int>();
		for(unsigned int i = 0; i < data->get_senders().size(); ++i)
		{
			this->terminals->push_back(0);
		}
		this->decompositionPaths = new vector<FlowPath*>;
		this->openedAggregationNodes = new set<int>;
		this->changedPredecessors = new vector<int>;
		this->virtualArcs = new map<int,int>;
		//this->virtualComponents = new map<int,int>;
		this->incomingVirtualArcs = new map<int, set<int> >;
		for(unsigned int i = 0; i < data->get_aggregation_nodes().size(); ++i)
		{
			(*this->incomingVirtualArcs)[(data->get_aggregation_nodes()[i])] = set<int>();
		}
		(*this->incomingVirtualArcs)[data->getReceiverConfiguration(0).get_receivers()[0]] = set<int>();
		this->usedPathForTerminal = new map<int, FlowPath*>;
		this->unconnectedTerminals = new vector<int>;
		this->alternativePaths = new vector<FlowPath*>;
		this->dijkstraQ = new set<pair<double, int> >;
		this->aggregationNodePriorityQ = new set<pair<double, int> >;
		this->minDistance = new vector<double>;
		for(int i = 0; i < data->graph().num_nodes(); ++i)
		{
			this->minDistance->push_back(0);
			(*(this->minDistance))[i] = numeric_limits<double>::infinity();

		}
	}

//	void destroy()
//	{
//		for(unsigned int i = 0; i < decompositionPaths->size(); ++i)
//		{
//			(*decompositionPaths)[i]->destroy();
//			delete ((*decompositionPaths)[i]);
//		}
//		decompositionPaths->clear();
//		delete this->flow;
//		delete this->leftCapacity;
//		delete this->predecessor;
//		delete this->terminals;
//		delete this->decompositionPaths;
//		delete this->openedAggregationNodes;
//		delete this->changedPredecessors;
//		delete this->virtualArcs;
//		delete this->numberOfIncomingNodes;
//		delete this->unconnectedTerminals;
//		delete this->dijkstraQ;
//		delete this->minDistance;
//	}

	~SCIP_HeurData(){
		for(unsigned int i = 0; i < decompositionPaths->size(); ++i)
		{
			(*decompositionPaths)[i]->destroy();
			delete ((*decompositionPaths)[i]);
		}
		decompositionPaths->clear();
		delete this->flow;
		delete this->leftCapacity;
		delete this->leftCapacityRollback;
		delete this->predecessor;
		delete this->terminals;
		delete this->decompositionPaths;
		delete this->openedAggregationNodes;
		delete this->changedPredecessors;
		delete this->virtualArcs;
		delete this->incomingVirtualArcs;
		delete this->usedPathForTerminal;
		delete this->unconnectedTerminals;
		delete this->alternativePaths;
		delete this->dijkstraQ;
		delete this->aggregationNodePriorityQ;
		delete this->minDistance;
	}
};


/*
 * Local methods
 */

/* put your local methods here, and declare them static */


/*
 * Callback methods of primal heuristic
 */


/** copy method for primal heuristic plugins (called when SCIP copies plugins) */
#if 0
static
SCIP_DECL_HEURCOPY(heurCopyFlowDecompositionRounding )
{  /*lint --e{715}*/
   SCIPerrorMessage("method of flow decomposition roundingprimal heuristic not implemented yet\n");
   SCIPABORT(); /*lint --e{527}*/

   return SCIP_OKAY;
}
#else
#define heurCopyFlowDecompositionRounding NULL
#endif


static
SCIP_DECL_HEURFREE(heurFreeFlowDecompositionRounding)
{
	return SCIP_OKAY;
	//SCIPfreeBufferArray(scip, &heurdata->dijkstraGraph.head);
	//SCIPfreeBufferArray(scip, &heurdata->dijkstraGraph.weight);
	//SCIPfreeBufferArray(scip, &heurdata->dijkstraGraph.outcnt);
	//SCIPfreeBufferArray(scip, &heurdata->dijkstraGraph.outbeg);
	//SCIPfreeBufferArray(scip, &heurdata->dist);
	//SCIPfreeBufferArray(scip, &heurdata->entry);
	//SCIPfreeBufferArray(scip, &heurdata->order);
	//SCIPfreeBufferArray(scip, &heurdata->pred);
	//heurdata->destroy();
	//SCIP_CALL( SCIPfreeSol(scip, &(heurdata->sol)) );
	//SCIPfreeMemory(scip, &heurdata);
	//return SCIP_OKAY;
}


/** initialization method of primal heuristic (called after problem was transformed) */

static
SCIP_DECL_HEURINIT(heurInitFlowDecompositionRounding)
{
	SCIP_HEURDATA* heurdata;
	heurdata = SCIPheurGetData(heur);
	if(heurdata == NULL)
	{
		return SCIP_OKAY;
	}
	CVSAPData* data = heurdata->data;
	if(data == NULL)
	{
		return SCIP_OKAY;
	}
	SCIP_CALL( SCIPcreateSol(scip, &(heurdata->sol), heur) );
   return SCIP_OKAY;
}



/** deinitialization method of primal heuristic (called before transformed problem is freed) */
static
SCIP_DECL_HEUREXIT(heurExitFlowDecompositionRounding)
{  /*lint --e{715}*/
	SCIP_HEURDATA* heurdata;
	heurdata = SCIPheurGetData(heur);
	assert(heurdata != NULL);
	SCIP_CALL( SCIPfreeSol(scip, &(heurdata->sol)) );
	delete heurdata;
	SCIPheurSetData(heur, NULL);
   return SCIP_OKAY;
}


/** solving process initialization method of primal heuristic (called when branch and bound process is about to begin) */
#if 0
static
SCIP_DECL_HEURINITSOL(heurInitsolFlowDecompositionRounding)
{  /*lint --e{715}*/
   SCIPerrorMessage("method of flow decomposition roundingprimal heuristic not implemented yet\n");
   SCIPABORT(); /*lint --e{527}*/

   return SCIP_OKAY;
}
#else
#define heurInitsolFlowDecompositionRounding NULL
#endif


/** solving process deinitialization method of primal heuristic (called before branch and bound process data is freed) */
#if 0
static
SCIP_DECL_HEUREXITSOL(heurExitsolFlowDecompositionRounding)
{  /*lint --e{715}*/
   SCIPerrorMessage("method of flow decomposition roundingprimal heuristic not implemented yet\n");
   SCIPABORT(); /*lint --e{527}*/

   return SCIP_OKAY;
}
#else
#define heurExitsolFlowDecompositionRounding NULL
#endif

/**
 * Returns the root of the connected component that the node identified by nodeId is attached to.
 * @param nodeId	id of the node
 * @param heurdata	pointer to the data structure used by the heuristic
 * @return	the root of the connected component the node is attached to or itself if the node is not attached to any other node
 */
int findRoot(int nodeId, SCIP_HeurData* heurdata)
{
	int parent = -1;
	map<int,int>::iterator it;
	if((it = heurdata->virtualArcs->find(nodeId)) != heurdata->virtualArcs->end())
	{
		parent = it->second;
		while((it = heurdata->virtualArcs->find(parent)) != heurdata->virtualArcs->end())
		{
			parent = it->second;
		}
	}
	else
	{
		parent = nodeId;
	}
	return parent;
}


typedef struct triple{
	int start;
	int end;
	int weight;
} triple;


/**
 * returns a partially cleared up FlowPath object, such that this object is stored in position heurdata->currentDecompositionPath
 * in heurdata->decompositionPaths
 * @param heurdata
 * @return
 */
FlowPath* getUnusedFlowPath(SCIP_HEURDATA* heurdata)
{
	heurdata->currentDecompositionPath++;
	if(heurdata->currentDecompositionPath >= (int)heurdata->decompositionPaths->size())
	{
		FlowPath* ptr = new FlowPath;
		heurdata->decompositionPaths->push_back(ptr);
	}
	FlowPath* flowPath = (*(heurdata->decompositionPaths))[heurdata->currentDecompositionPath];
	flowPath->path->clear();
	flowPath->isFeasible = true;
	vector<int>* currentPath = flowPath->path;
	currentPath->clear();
	return flowPath;
}

/**
 * a heuristic for the CVSAP problem that works in 3 phases:
 * Phase 1: 	(Try to) connect nodes based on Flow Decomposition
 * Phase 2:		Connect unconnected terminals using shortest paths
 * Phase 3:		Polish the solution by trying to deactivate aggregation nodes
 */
static
SCIP_DECL_HEUREXEC(heurExecFlowDecompositionRounding)
{
	*result = SCIP_DIDNOTRUN;

	SCIP_HEURDATA* heurdata;
	heurdata = SCIPheurGetData(heur);
	if(heurdata == NULL)
	{
		return SCIP_OKAY;
	}
	CVSAPData* data = heurdata->data;
	if(data == NULL)
	{
		return SCIP_OKAY;
	}


	bool debug = data->getParameters()->isDebugHeuristicFlowdecoround();
	 /* since the timing is SCIP_HEURTIMING_AFTERLPNODE, the current node should have an LP */
	assert(SCIPhasCurrentNodeLP(scip));

	 /* only call heuristic, if an optimal LP solution is at hand */
	if( SCIPgetLPSolstat(scip) != SCIP_LPSOLSTAT_OPTIMAL )
		return SCIP_OKAY;
	/* get the working solution from heuristic's local data */
	assert(heurdata->sol != NULL);

	/* copy the current LP solution to the working solution */
	SCIP_CALL( SCIPlinkLPSol(scip, heurdata->sol) );

	*result = SCIP_DIDNOTFIND;

	if(debug) cout << "starting heuristic Flow Decomposition Rounding" << endl;

	//read flow and capacity information
	const Digraph& graph = data->graph();
	for (int e = 0; e < graph.num_edges(); ++e) {
		const double x = SCIPgetSolVal(scip, heurdata->sol, data->arc_var(e));
		int rounded = ceil(x * data->getParameters()->getScale());
		(*(heurdata->flow))[e] = rounded;
		(*(heurdata->leftCapacity))[e] = graph.get_capacity(e);
		if(data->graph().tgt_node(e) == data->getSuperSinkAggregationId())
		{
			if(debug) cout << "flow to aggregation sink from " << data->graph().src_node(e) << "." << data->graph().get_node_name(data->graph().src_node(e)) << " : " << x << endl;
		}
	}

	SCIP_SOL* newSol;

	vector<int> terminals(data->get_senders());
	deque<int> Q;

	double dist;
	double newDist;
	int edge_target;
	int edge_source;
	int edge;
	int currentNode;
	int foundTarget;
	int minCap;
	bool found = false;
	bool abort = false;
	bool rollbackCapacitiesChanged = false;

	//initialize data structures
	for(map<int, set<int> >::iterator it = heurdata->incomingVirtualArcs->begin(); it != heurdata->incomingVirtualArcs->end(); ++it)
	{
		it->second.clear();
	}
	heurdata->virtualArcs->clear();
	heurdata->openedAggregationNodes->clear();
	heurdata->unconnectedTerminals->clear();

	//other data structures are cleaned up directly after the last's execution

	/*
	 * PHASE 1a: Connecting nodes based on flow decomposition
	 */

	if(debug) cout << "phase 1: connecting nodes based on flow decomposition (if possible)" << endl;
	while(terminals.size() > 0)
	{
		//select a random terminal
		int pos = rand() % terminals.size();
		int terminal = terminals[pos];
		terminals.erase(terminals.begin() + pos);

		//we need to find a decomposition such that the flow along the paths amounts to the following value
		int flowToFind = (*(heurdata->flow))[data->getEdgeFromSupersourceToNode(terminal)];
		heurdata->currentDecompositionPath = -1;
		abort = false;
		//performs a breadth first search from the current terminal to the super sinks
		while(flowToFind > 0 && !abort)
		{
			Q.clear();
			Q.push_front(terminal);
			(*(heurdata->predecessor))[terminal] = graph.num_edges();
			heurdata->changedPredecessors->push_back(terminal);
			found = false;
			while(!Q.empty())
			{
				/*
				 * 	BREADTH FIRST SEARCH
				 */
				currentNode = Q.front();
				Q.pop_front();
				const std::vector<int>&  currentOutEdges = graph.all_out_edges(currentNode);
				for (unsigned int i=0; i< currentOutEdges.size(); ++i)
				{
					edge_source = graph.src_node(currentOutEdges[i]);
					edge_target = graph.tgt_node(currentOutEdges[i]);
					if ((*(heurdata->predecessor))[edge_target] == -1 && (*(heurdata->flow))[currentOutEdges[i]] > 0)
					{
						(*(heurdata->predecessor))[edge_target] = currentOutEdges[i];
						heurdata->changedPredecessors->push_back(edge_target);
						if(edge_target == data->getSuperSinkReceiverId() || edge_target == data->getSuperSinkAggregationId())
						{
							if(edge_target == data->getSuperSinkAggregationId())
							{
								if(debug) cout << "found path towards aggregation sink!" << endl;
							}
							found = true;
							foundTarget = edge_target;
							break;
						}
						(*(heurdata->predecessor))[edge_target] = currentOutEdges[i];
						{
							//BFS!
							Q.push_back(edge_target);
						}
					}
				}
				if(found){
					break;
				}
			}
			if(!found)
			{
				abort = true;
				goto cleanup;
			}
			else
			{
				/*
				 * RECONSTRUCTION OF PATH
				 */
				minCap = flowToFind;

				//get an unused FlowPath object
				FlowPath* flowPath = getUnusedFlowPath(heurdata);
				vector<int>* currentPath = flowPath->path;
				currentPath->clear();

				currentNode = foundTarget;
				//reconstruct path
				while ((edge = (*(heurdata->predecessor))[currentNode]) != graph.num_edges())
				{
					edge_source = graph.src_node(edge);
					edge_target = graph.tgt_node(edge);
					//if(debug) cout << "currentNode " << currentNode << endl;
					//if(debug) cout << "edge: (" << edge_source << "," << edge_target << ")" << endl;
					if(edge_target == currentNode)
					{
						currentNode = edge_source;
						currentPath->push_back(edge);
						if((*(heurdata->flow))[edge] < minCap)
						{
							minCap = (*(heurdata->flow))[edge];
						}
						if((*(heurdata->leftCapacity))[edge] == 0)
						{
							//as no flow is available, we cannot use this path, but we continue, as we decompose all of the flow
							flowPath->isFeasible = false;
						}
					}
					else if(edge_source == currentNode)
					{
						assert(0);
					}
					else
					{
						assert(0);
					}
				}

				/*
				 *	REMOVE FLOW ALONG THE PATH
				 */
				flowToFind -= minCap;
				for(unsigned int i = 0; i < currentPath->size(); ++i)
				{
					(*(heurdata->flow))[(*currentPath)[i]] = (*(heurdata->flow))[(*currentPath)[i]] - minCap;
				}

				//lookup to which nodes the nodes are connected
				int rootOther = findRoot(graph.src_node((*currentPath)[0]), heurdata);
				int rootTerminal = findRoot(terminal, heurdata);

				//if the flowPath cannot possible be used or using this would create a cycle, discard this path
				if(!flowPath->isFeasible || rootOther == rootTerminal)
				{
					//simply discard this path
					heurdata->currentDecompositionPath--;
					goto cleanup;
				}

				//if we are here, we could use the path

				//set information on the flow path
				flowPath->startNode = terminal;
				flowPath->endNode = graph.src_node((*currentPath)[0]);
				flowPath->flow = minCap;
			}

			//cleanup predecessors
cleanup:	for(unsigned int i = 0; i < heurdata->changedPredecessors->size(); ++i)
			{
				(*(heurdata->predecessor))[(*(heurdata->changedPredecessors))[i]] = -1;
			}
			heurdata->changedPredecessors->clear();
		}
		/*
		 * PHASE 1b.	RANDOMIZED SELECTION OF PATH
		 */

		FlowPath* selectedPath = NULL;
		if(heurdata->currentDecompositionPath == -1)
		{
			//do not do anything as no feasible path was found based on the flow decomposition
		}
		else if(heurdata->currentDecompositionPath == 0)
		{
			//select this path as it is the only feasible one
			selectedPath = (*(heurdata->decompositionPaths))[0];
		}
		else{
			//select a path uniformly distributed according to the flow its carrying
			flowToFind = (*(heurdata->flow))[data->getEdgeFromSupersourceToNode(terminal)];
			int pathSelector = rand() % flowToFind;
			int accumulated = 0;
			int currentPath = -1;
			do
			{
				currentPath++;
				accumulated += (*(heurdata->decompositionPaths))[currentPath]->flow;
			}while(pathSelector > accumulated && currentPath < heurdata->currentDecompositionPath);
			selectedPath = (*(heurdata->decompositionPaths))[currentPath];
		}

		/*
		 * PHASE 1c.	RESERVE FLOW ALONG THE PATH AND SET META-INFORMATION
		 */
		if(selectedPath == NULL)
		{
			heurdata->unconnectedTerminals->push_back(terminal);
		}
		else
		{
			int connectingTo = selectedPath->endNode;
			//set virtual arc information accordingly
			(*(heurdata->usedPathForTerminal))[terminal] = selectedPath;
			(*(heurdata->virtualArcs))[terminal] = connectingTo;
			heurdata->incomingVirtualArcs->at(connectingTo).insert(terminal);

			if(debug) cout << "abstract path: " << selectedPath->startNode << "." << data->graph().get_node_name(selectedPath->startNode) << " to " << selectedPath->endNode << "." << data->graph().get_node_name(selectedPath->endNode) << endl;
			if(debug) cout << "connecting to " << connectingTo << "." << data->graph().get_node_name(connectingTo) << endl;
			//if we connect to a previously unopened aggregation node, open it
			if((graph.isSpecialNode(selectedPath->endNode) & AGGREGATION_NODE_FLAG) == AGGREGATION_NODE_FLAG || find(data->get_aggregation_nodes().begin(), data->get_aggregation_nodes().end(), selectedPath->endNode) != data->get_aggregation_nodes().end())
			{
				if(debug) cout << "connecting to aggregation node" << endl;
				if(heurdata->openedAggregationNodes->find(selectedPath->endNode) == heurdata->openedAggregationNodes->end())
				{
					heurdata->openedAggregationNodes->insert(selectedPath->endNode);
					terminals.push_back(selectedPath->endNode);
				}
			}
			//adapt capacities
			for(unsigned int i = 0; i < selectedPath->path->size(); ++i)
			{
				(*(heurdata->leftCapacity))[(*(selectedPath->path))[i]] = (*(heurdata->leftCapacity))[(*(selectedPath->path))[i]]-1;
			}

			//remove the path from the storage, as the pointer is now used by heurdata->usedPathForTerminal
			heurdata->decompositionPaths->erase(find(heurdata->decompositionPaths->begin(), heurdata->decompositionPaths->end() + heurdata->currentDecompositionPath, selectedPath));
			heurdata->currentDecompositionPath--;

		}
	}

	/*
	 * 	END OF PHASE 1
	 */

	if(debug) cout << "unconnected terminals after phase 1: " << heurdata->unconnectedTerminals->size() << endl;
	if(debug) cout << "opened aggregation nodes after phase 1: " << heurdata->openedAggregationNodes->size() << endl;

	/*
	 * 	PHASE 2: 	CONNECT UNCONNECTED TERMINALS USING SHORTEST PATHS
	 */

	if(heurdata->unconnectedTerminals->size() > 0)
	{
		//take any of the unconnected terminals and try to connect them
		abort = false;
		while(heurdata->unconnectedTerminals->size() > 0 && !abort)
		{
			int terminalToConnect = heurdata->unconnectedTerminals->back();
			heurdata->unconnectedTerminals->pop_back();

			/*
			 * PHASE 2	DIJKSTRA
			 */
			heurdata->dijkstraQ->clear();
			heurdata->dijkstraQ->insert(make_pair(0.0, terminalToConnect));

			(*(heurdata->predecessor))[terminalToConnect] = graph.num_edges();
			heurdata->changedPredecessors->push_back(terminalToConnect);
			(*(heurdata->minDistance))[terminalToConnect] = 0.0;
			found = false;
			while(heurdata->dijkstraQ->size() > 0)
			{
				dist = heurdata->dijkstraQ->begin()->first;
				currentNode = heurdata->dijkstraQ->begin()->second;
				heurdata->dijkstraQ->erase(make_pair(dist, currentNode));
				if(currentNode == data->getSuperSinkAggregationId() || currentNode == data->getSuperSinkReceiverId())
				{
					found = true;
					break;
				}
				const std::vector<int>&  currentOutEdges = graph.all_out_edges(currentNode);
				for (unsigned int i=0; i< currentOutEdges.size(); ++i)
				{
					edge = currentOutEdges[i];
					edge_source = graph.src_node(currentOutEdges[i]);
					edge_target = graph.tgt_node(currentOutEdges[i]);
					newDist = dist + graph.get_cost(edge);
					//if(debug) cout << "fooooo: " << (*(heurdata->minDistance))[edge_target] << endl;
					if ((*(heurdata->leftCapacity))[currentOutEdges[i]] > 0 && newDist < (*(heurdata->minDistance))[edge_target])
					{
						if(edge_target == data->getSuperSinkAggregationId())
						{
							if(heurdata->openedAggregationNodes->find(edge_source) == heurdata->openedAggregationNodes->end())
							{
								//if this node is not opened, we cannot connect via edge_source
								continue;
							}
							if(findRoot(edge_source, heurdata) == findRoot(terminalToConnect, heurdata))
							{
								//in this case, we would create a loop and therefore do not allow this.
								continue;
							}
						}
						(*(heurdata->predecessor))[edge_target] = currentOutEdges[i];
						heurdata->dijkstraQ->erase(make_pair((*(heurdata->minDistance))[edge_target], edge_target));
						(*(heurdata->minDistance))[edge_target] = newDist;
						heurdata->dijkstraQ->insert(make_pair(newDist, edge_target));
						heurdata->changedPredecessors->push_back(edge_target);
					}
				}
			}
			if(!found)
			{
				abort = true;
			}
			else
			{
				/*
				 *	PATH RECONSTRUCTION
				 */
				//we have found a path
				FlowPath* flowPath = getUnusedFlowPath(heurdata);
				flowPath->startNode = terminalToConnect;
				flowPath->isFeasible = true;
				//store the path information in the flowPath

				while ((edge = (*(heurdata->predecessor))[currentNode]) != graph.num_edges())
				{
					edge_source = graph.src_node(edge);
					edge_target = graph.tgt_node(edge);
					if(edge_target == currentNode)
					{
						(*(heurdata->leftCapacity))[edge] = (*(heurdata->leftCapacity))[edge] - 1;
						flowPath->path->push_back(edge);
						currentNode = edge_source;
					}
					else
					{
						assert(0);
					}
				}
				//set virtual information right
				flowPath->endNode = data->graph().src_node(flowPath->path->at(0));
				(*(heurdata->virtualArcs))[terminalToConnect] = flowPath->endNode;
				(*(heurdata->usedPathForTerminal))[terminalToConnect] = flowPath;
				heurdata->incomingVirtualArcs->at(flowPath->endNode).insert(terminalToConnect);
				//as flowPath is now in use, we remove it from the storage
				heurdata->decompositionPaths->erase(heurdata->decompositionPaths->begin() + heurdata->currentDecompositionPath);
				heurdata->currentDecompositionPath--;
			}
			//cleanup
			for(vector<int>::iterator it = heurdata->changedPredecessors->begin(); it != heurdata->changedPredecessors->end(); ++it)
			{
				(*(heurdata->minDistance))[*it] = numeric_limits<double>::infinity();
				(*(heurdata->predecessor))[*it] = -1;
			}
		}
	}
	/*
	 * 	END PHASE 2
	 */

	if(abort)
	{
		*result = SCIP_DIDNOTFIND;
		if(debug) cout << "abort in phase 2 with " << heurdata->unconnectedTerminals->size() << " many unconnected terminals " << endl;
		if(debug) cout << "opened aggregation nodes after phase 2: " << heurdata->openedAggregationNodes->size() << endl;
		return SCIP_OKAY;
	}
	//if we are here, we have constructed a solution!
	if(debug) cout << "heuristic FlowDecoRound has constructed a solution!" << endl;

	/*
	 * 	PHASE 3: SOLUTION POLISHING: TRY TO DEACTIVATE AGGREGATION NODES TO YIELD A BETTER SOLUTION
	 */
	if(heurdata->openedAggregationNodes->size() > 0)
	{
		//indicates whether the rollback capacities must be re-read
		rollbackCapacitiesChanged = true;

		int currentIteration = 0;

		//we use the aggregationNodePriorityQ to store all activated aggregation nodes corresponding to the following metric:
		heurdata->aggregationNodePriorityQ->clear();
		//calculate the opening cost of each aggregation node divided by the number of terminals being served by it
		for(vector<int>::const_iterator aggIt = data->get_aggregation_nodes().begin(); aggIt != data->get_aggregation_nodes().end(); ++aggIt)
		{
			if(heurdata->openedAggregationNodes->find(*aggIt) != heurdata->openedAggregationNodes->end())
			{
				if(debug ) cout << *aggIt << " is an open aggregation node !" << endl;
				double costPerTerminal = (-1.0) * data->get_aggregation_installation_cost(*aggIt) / heurdata->incomingVirtualArcs->at(*aggIt).size();
				heurdata->aggregationNodePriorityQ->insert(make_pair(costPerTerminal, *aggIt));
			}
		}

		while(heurdata->aggregationNodePriorityQ->size() > 0 && currentIteration < data->getParameters()->getMaxNumberOfIterationsSolutionPolishing())
		{
			currentIteration++;

			/*
			 * PHASE 3a:	SELECT AN ACTIVE AGGREGATION NODE TO REMOVE
			 */

			if(heurdata->aggregationNodePriorityQ->size() == 0)
			{
				break;
			}
			int aggNode = heurdata->aggregationNodePriorityQ->begin()->second;

			if(debug)  cout << "try to remove " << aggNode << " from solution" << endl;
			FlowPath* pathForAggregationNodeToBeRemoved = heurdata->usedPathForTerminal->at(aggNode);

			//disconnect all nodes connected to aggNode (which shall be removed)
			heurdata->unconnectedTerminals->clear();
			heurdata->unconnectedTerminals->insert(heurdata->unconnectedTerminals->begin(), heurdata->incomingVirtualArcs->at(aggNode).begin(), heurdata->incomingVirtualArcs->at(aggNode).end());
			double budget = data->get_aggregation_installation_cost(aggNode);

			//store the leftCapacities as they were before
			if(rollbackCapacitiesChanged)
			{
				for(int edgeIt = 0; edgeIt < data->graph().num_edges(); ++edgeIt)
				{
					(*(heurdata->leftCapacityRollback))[edgeIt] = heurdata->leftCapacity->at(edgeIt);
				}
				rollbackCapacitiesChanged = false;
			}

			//remove the flow from the terminals according to the flowPaths that were used before
			for(unsigned int i = 0; i < heurdata->unconnectedTerminals->size(); ++i)
			{
				int node = heurdata->unconnectedTerminals->at(i);
				if(debug ) cout << "handle node " << node << endl;
				FlowPath* flowPath = heurdata->usedPathForTerminal->at(heurdata->unconnectedTerminals->at(i));
				for(unsigned int j = 0; j < flowPath->path->size(); ++j)
				{
					(*(heurdata->leftCapacity))[flowPath->path->at(j)] = (*(heurdata->leftCapacity))[flowPath->path->at(j)] + 1;
					budget += data->graph().get_cost(flowPath->path->at(j));
				}
			}
			//remove the flow from the path used by the aggregation node
			for(unsigned int j = 0; j < pathForAggregationNodeToBeRemoved->path->size(); ++j)
			{
				(*(heurdata->leftCapacity))[pathForAggregationNodeToBeRemoved->path->at(j)] = (*(heurdata->leftCapacity))[pathForAggregationNodeToBeRemoved->path->at(j)] + 1;
				budget += data->graph().get_cost(pathForAggregationNodeToBeRemoved->path->at(j));
			}


			abort = false;
			//remove the aggNode from the list of openedAggregationNodes such that no node will be connected to it
			heurdata->openedAggregationNodes->erase(aggNode);

			unsigned int terminalIndex = 0;
			//insert all used alternative paths into our storage
			heurdata->alternativePaths->clear();
			/*
			 * PHASE 3b:	TRY TO RECONNECT TERMINALS USING DIJKSTRA
			 */
			//for each terminal, a FlowPath will be created which will be stored in heurdata->alternativePaths
			for(; terminalIndex < heurdata->unconnectedTerminals->size(); ++terminalIndex)
			{
				int terminalToConnect = heurdata->unconnectedTerminals->at(terminalIndex);
				//run dijkstra on the residual graph to connect this terminal to the nearest aggregation node / root
				heurdata->dijkstraQ->clear();
				heurdata->dijkstraQ->insert(make_pair(0.0, terminalToConnect));

				(*(heurdata->predecessor))[terminalToConnect] = graph.num_edges();
				heurdata->changedPredecessors->push_back(terminalToConnect);
				(*(heurdata->minDistance))[terminalToConnect] = 0.0;
				found = false;
				while(heurdata->dijkstraQ->size() > 0)
				{
					dist = heurdata->dijkstraQ->begin()->first;
					currentNode = heurdata->dijkstraQ->begin()->second;
					heurdata->dijkstraQ->erase(make_pair(dist, currentNode));
					if(currentNode == data->getSuperSinkAggregationId() || currentNode == data->getSuperSinkReceiverId())
					{
						found = true;
						break;
					}
					const std::vector<int>&  currentOutEdges = graph.all_out_edges(currentNode);
					for (unsigned int i=0; i< currentOutEdges.size(); ++i)
					{
						edge = currentOutEdges[i];
						edge_source = graph.src_node(currentOutEdges[i]);
						edge_target = graph.tgt_node(currentOutEdges[i]);
						newDist = dist + graph.get_cost(edge);
						if ((*(heurdata->leftCapacity))[currentOutEdges[i]] > 0 && newDist < (*(heurdata->minDistance))[edge_target])
						{
							if(edge_target == data->getSuperSinkAggregationId())
							{
								if(heurdata->openedAggregationNodes->find(edge_source) == heurdata->openedAggregationNodes->end())
								{
									//if this node is not opened, we cannot connect via edge_source
									continue;
								}
								if(findRoot(edge_source, heurdata) == findRoot(terminalToConnect, heurdata))
								{
									//in this case, we would create a loop and therefore do not allow this.
									continue;
								}
							}
							(*(heurdata->predecessor))[edge_target] = currentOutEdges[i];
							heurdata->dijkstraQ->erase(make_pair((*(heurdata->minDistance))[edge_target], edge_target));
							(*(heurdata->minDistance))[edge_target] = newDist;
							heurdata->dijkstraQ->insert(make_pair(newDist, edge_target));
							heurdata->changedPredecessors->push_back(edge_target);
						}
					}
				}
				if(!found)
				{
					abort = true;
					break;
				}
				else
				{
					/*
					 * RECONSTRUCT PATH
					 */
					FlowPath* flowPath = getUnusedFlowPath(heurdata);
					flowPath->startNode = terminalToConnect;
					flowPath->isFeasible = true;

					while ((edge = (*(heurdata->predecessor))[currentNode]) != graph.num_edges())
					{
						edge_source = graph.src_node(edge);
						edge_target = graph.tgt_node(edge);
						if(edge_target == currentNode)
						{
							(*(heurdata->leftCapacity))[edge] = (*(heurdata->leftCapacity))[edge] - 1;
							flowPath->path->push_back(edge);
							currentNode = edge_source;
							budget -= data->graph().get_cost(edge);
						}
						else
						{
							assert(0);
						}
					}
					if(budget <= 0)
					{
						abort = true;
						break;
					}
					flowPath->endNode = data->graph().src_node((*(flowPath->path))[0]);
					//store the path and remove it from the storage
					heurdata->alternativePaths->push_back(flowPath);
					heurdata->decompositionPaths->erase(heurdata->decompositionPaths->begin() + heurdata->currentDecompositionPath);
					heurdata->currentDecompositionPath--;
				}
				//cleanup
				for(vector<int>::iterator it = heurdata->changedPredecessors->begin(); it != heurdata->changedPredecessors->end(); ++it)
				{
					(*(heurdata->minDistance))[*it] = numeric_limits<double>::infinity();
					(*(heurdata->predecessor))[*it] = -1;
				}
			}
			if(abort)
			{
				if(debug) cout << "abort" << endl;
				//revert changes
				heurdata->openedAggregationNodes->insert(aggNode);
				heurdata->decompositionPaths->insert(heurdata->decompositionPaths->begin(), heurdata->alternativePaths->begin(), heurdata->alternativePaths->end());
				heurdata->alternativePaths->clear();
				heurdata->unconnectedTerminals->clear();
				//revert changes made to flow in the network
				for(int edgeIt = 0; edgeIt < data->graph().num_edges(); ++edgeIt)
				{
					(*(heurdata->leftCapacity))[edgeIt] = heurdata->leftCapacityRollback->at(edgeIt);
				}
			}
			else
			{
				//if we did not abort, then for all nodes connected to aggNode we have found another path and
				//the objective value decreases
				if(debug) cout << "accept" << endl;

				rollbackCapacitiesChanged = true;

				//we need to change the virtual information
				heurdata->incomingVirtualArcs->at(aggNode).clear();
				heurdata->decompositionPaths->push_back(pathForAggregationNodeToBeRemoved);
				(*(heurdata->usedPathForTerminal))[aggNode] = NULL;
				heurdata->incomingVirtualArcs->at(pathForAggregationNodeToBeRemoved->endNode).erase(aggNode);
				//set everything new!
				for(terminalIndex = 0; terminalIndex < heurdata->unconnectedTerminals->size(); ++terminalIndex)
				{
					int terminalToConnect = heurdata->unconnectedTerminals->at(terminalIndex);
					FlowPath* oldPath = heurdata->usedPathForTerminal->at(terminalToConnect);
					FlowPath* newPath = heurdata->alternativePaths->at(terminalIndex);

					if(debug)
					{
						cout << "oldPath: " << oldPath->startNode << " -> " << oldPath->endNode;
						for(unsigned foo = 0; foo < oldPath->path->size(); ++foo)
						{
							cout << "(" << data->graph().src_node(oldPath->path->at(foo)) << "." << data->graph().get_node_name(data->graph().src_node(oldPath->path->at(foo))) << "," << data->graph().tgt_node(oldPath->path->at(foo)) << "." << data->graph().get_node_name(data->graph().tgt_node(oldPath->path->at(foo))) << "), ";
						}
						cout <<endl;
						cout << "newPath: " << newPath->startNode << " -> " << newPath->endNode << endl;
						for(unsigned foo = 0; foo < newPath->path->size(); ++foo)
						{
							cout << "(" << data->graph().src_node(newPath->path->at(foo)) << "." << data->graph().get_node_name(data->graph().src_node(newPath->path->at(foo))) << "," << data->graph().tgt_node(newPath->path->at(foo)) << "." << data->graph().get_node_name(data->graph().tgt_node(newPath->path->at(foo))) << "), ";
						}
						cout <<endl;
					}
					int connectingToNew = newPath->endNode;

					(*(heurdata->virtualArcs))[terminalToConnect] = connectingToNew;
					(*(heurdata->usedPathForTerminal))[terminalToConnect] = newPath;
					heurdata->incomingVirtualArcs->at(connectingToNew).insert(terminalToConnect);
					heurdata->incomingVirtualArcs->at(oldPath->endNode).erase(oldPath->startNode);
					heurdata->decompositionPaths->push_back(oldPath);
				}

				//lastly refresh the priority queue
				for(vector<int>::const_iterator aggIt = data->get_aggregation_nodes().begin(); aggIt != data->get_aggregation_nodes().end(); ++aggIt)
				{
					if(heurdata->openedAggregationNodes->find(*aggIt) != heurdata->openedAggregationNodes->end())
					{
						if(debug ) cout << *aggIt << " is an open aggregation node !" << endl;
						double costPerTerminal = (-1.0) * data->get_aggregation_installation_cost(*aggIt) / heurdata->incomingVirtualArcs->at(*aggIt).size();
						heurdata->aggregationNodePriorityQ->insert(make_pair(costPerTerminal, *aggIt));
					}
				}
			}
			heurdata->alternativePaths->clear();
			heurdata->unconnectedTerminals->clear();
			heurdata->aggregationNodePriorityQ->clear();
		}
	}
	/*
	 * END PHASE 3
	 */

	/*
	 * SET SOLUTION!
	 */

	SCIP_CALL ( SCIPcreateSol(scip, &newSol, heur));
	//set chi_A variables
	for(vector<int>::const_iterator aggIt = data->get_aggregation_nodes().begin(); aggIt != data->get_aggregation_nodes().end(); ++aggIt)
	{
		if(heurdata->openedAggregationNodes->find(*aggIt) == heurdata->openedAggregationNodes->end())
		{
			SCIPsetSolVal(scip, newSol, data->get_chi_A(*aggIt), 0.0);
			SCIPsetSolVal(scip, newSol, data->arc_var(data->getEdgeFromSupersourceToNode(*aggIt)), 0.0);
		}
		else
		{
			SCIPsetSolVal(scip, newSol, data->get_chi_A(*aggIt), 1.0);
			SCIPsetSolVal(scip, newSol, data->arc_var(data->getEdgeFromSupersourceToNode(*aggIt)), 1.0);
		}
	}
	for(vector<int>::const_iterator terminalIt = data->get_senders().begin(); terminalIt != data->get_senders().end(); ++terminalIt)
	{
		SCIPsetSolVal(scip, newSol, data->arc_var(data->getEdgeFromSupersourceToNode(*terminalIt)), 1.0);
	}
	//we assume only one receiver
	SCIPsetSolVal(scip, newSol, data->get_chi_R(0), 1.0);

	//set arc variables
	for(edge = 0; edge < data->graph().num_edges(); ++edge)
	{
		edge_source = data->graph().src_node(edge);
		edge_target = data->graph().tgt_node(edge);
		if(edge_source == data->getSuperSourceId())
		{
			continue;
		}
		int usage = data->graph().get_capacity(edge) - (*(heurdata->leftCapacity))[edge];
		SCIPsetSolVal(scip, newSol, data->arc_var(edge), usage);
	}
	double newSolObj = SCIPgetSolOrigObj(scip, newSol);

	SCIP_SOL* bestSol = SCIPgetBestSol(scip);

	double bestObj = numeric_limits<double>::max();
	if(bestSol != NULL)
	{
		bestObj = SCIPgetSolOrigObj(scip, bestSol);
	}
	if(bestObj <= newSolObj)
	{
		*result = SCIP_DIDNOTFIND;
		if(debug) cout << "solution poses no improvement!" << endl;
		return SCIP_OKAY;
	}

	SCIP_Bool acceptedSolution;
	SCIP_CALL ( SCIPtrySolFree(scip, &newSol, TRUE, TRUE, TRUE, TRUE, &acceptedSolution));
	{
		if(debug) cout << "solution was not accepted" <<endl;
	}
	return SCIP_OKAY;
}


/*
 * primal heuristic specific interface methods
 */

/** creates the xyz primal heuristic and includes it in SCIP */
SCIP_RETCODE SCIPincludeHeurFlowDecompositionRounding(
   SCIP*                 scip,                /**< SCIP data structure */
   CVSAPData* 			 data
   )
{
   SCIP_HEURDATA* heurdata;
   SCIP_HEUR* heur;

   /* create flow decomposition roundingprimal heuristic data */
   heurdata = NULL;

   //SCIP_CALL( SCIPallocMemory(scip, &heurdata) );
   heurdata = new SCIP_HeurData;
   heurdata->data = data;
   heurdata->init();

   heur = NULL;

   /* include primal heuristic */
#if 0
   /* use SCIPincludeHeur() if you want to set all callbacks explicitly and realize (by getting compiler errors) when
    * new callbacks are added in future SCIP versions
    */
   SCIP_CALL( SCIPincludeHeur(scip, HEUR_NAME, HEUR_DESC, HEUR_DISPCHAR, HEUR_PRIORITY, HEUR_FREQ, HEUR_FREQOFS,
         HEUR_MAXDEPTH, HEUR_TIMING, HEUR_USESSUBSCIP,
         heurCopyFlowDecompositionRounding, heurFreeFlowDecompositionRounding, heurInitFlowDecompositionRounding, heurExitFlowDecompositionRounding, heurInitsolFlowDecompositionRounding, heurExitsolFlowDecompositionRounding, heurExecFlowDecompositionRounding,
         heurdata) );
#else
   /* use SCIPincludeHeurBasic() plus setter functions if you want to set callbacks one-by-one and your code should
    * compile independent of new callbacks being added in future SCIP versions
    */


   SCIP_CALL( SCIPincludeHeurBasic(scip, &heur,
         HEUR_NAME, HEUR_DESC, HEUR_DISPCHAR, HEUR_PRIORITY, HEUR_FREQ, HEUR_FREQOFS,
         HEUR_MAXDEPTH, HEUR_TIMING, HEUR_USESSUBSCIP, heurExecFlowDecompositionRounding, heurdata) );

   assert(heur != NULL);
   
   /* set non fundamental callbacks via setter functions */
   SCIP_CALL( SCIPsetHeurCopy(scip, heur, heurCopyFlowDecompositionRounding) );
   SCIP_CALL( SCIPsetHeurFree(scip, heur, heurFreeFlowDecompositionRounding) );
   SCIP_CALL( SCIPsetHeurInit(scip, heur, heurInitFlowDecompositionRounding) );
   SCIP_CALL( SCIPsetHeurExit(scip, heur, heurExitFlowDecompositionRounding) );
   SCIP_CALL( SCIPsetHeurInitsol(scip, heur, heurInitsolFlowDecompositionRounding) );
   SCIP_CALL( SCIPsetHeurExitsol(scip, heur, heurExitsolFlowDecompositionRounding) );
#endif

   /* add flow decomposition roundingprimal heuristic parameters */

   return SCIP_OKAY;
}
