/**
 * @file	Digraph.h
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Definition of a simple directed graph class. This header also contains inline definitions for the
 * getter methods.
 *
 */

#ifndef DIGRAPH_H
#define DIGRAPH_H

#include <cassert>
#include <limits>
#include <vector>
#include <string>

#include "objscip/objscip.h"

#define NORMAL_NODE_FLAG 0
#define AGGREGATION_NODE_FLAG 2
#define SENDING_NODE_FLAG 1



/**
 * A simple implementation of a directed graph in which both nodes and links are identified with integer numbers.
 * Nodes are numbered from 0 to n-1 where n denotes the number of nodes.
 * Links are numbered accordingly.
 * Via the functions src_node and tgt_node the start and end node of a link can be accessed.
 * Furthermore, this graph distinguishes between edges that shall be included when separating connectivity inequalities.
 *
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief
 */
class Digraph {

public:

   Digraph();
   
   /**
    * @return  number of nodes in digraph
    */
   int num_nodes() const;
   
   /**
    * @return number of edges in digraph
    */
   int num_edges() const;
   
   /**
    * adds a new node to the graph
    * @param nodeName
    * @param isSpecialNode	flag of the node to be added: 0 for normal, 1 for sending nodes and 2 for aggregation nodes
    * @return id of the node just added
    */
   int add_node(std::string nodeName, int isSpecialNode);

   /**
    * adds a new edges between existing nodes and returns new edge id
    * @param source_node
    * @param target_node
    * @param capacity
    * @param cost
    * @param includeInFlow	For all edges except the edges from aggregation nodes to the aggregation super sink, this flag should be set to true and false otherwise.
    * @return id of edge just added
    */
   int add_edge( const int source_node, const int target_node, int capacity, double cost, bool includeInFlow);

   /**
    * @param edge
    * @return source node of edge
    */
   int src_node( const int edge ) const;


   /**
   * @param edge
   * @return target node of edge
   */
   int tgt_node( const int edge )const;

   /**
    * @param node
    * @return vector of outgoing edges from node that shall be included when separating cuts
    */
   const std::vector<int>& out_edges( const int node ) const ;

   /**
    * @param node
    * @return vector of incoming edges from node that shall be included when separating cuts
    */
   const std::vector<int>& in_edges( const int node ) const ;
   
   /**
    * @param node
    * @return vector of all outgoing edges from node, even those not to be included when separating cuts
    */
   const std::vector<int>& all_out_edges( const int node ) const ;

   /**
    * @param node
    * @return vector of all outgoing edges from node, even those not to be included when separating cuts
    */
   const std::vector<int>& all_in_edges( const int node ) const ;

   /**
    * @param node
    * @return name of node
    */
   const std::string& get_node_name (const int node) const;

   /**
    * @param edge
    * @return	cost of edge
    */
   double get_cost (const int edge) const;

   /**
    * @param edge
    * @return capacity of edge
    */
   int get_capacity (const int edge) const;

   /**
    * @param nodeId
    * @return flag of given node: 0 for normal nodes, 1 for sending nodes and 2 for aggregation nodes
    */
   int isSpecialNode(const int nodeId) const;

   /**
    *
    * @param nodeId
    * @return true if given nodeId corresponds to a possible aggregation node and false otherwise
    */
   bool isAggregationNode(int nodeId) const;

   /**
    *
    * @param nodeId
    * @return true if given nodeId corresponds to a sending node and false otherwise
    */
   bool isSendingNode(int nodeId) const;

   
private:
   /** number of nodes contained in the graph*/
   int                              num_nodes_;
   /** number of edges contained in the graph*/
   int                              num_edges_;

   /** vector with the size of the number of edges storing the head (target) of each edge*/
   std::vector< int >               tgt_;
   /** vector with the size of the number of edges storing the tail (source) of each edge*/
   std::vector< int >               src_;


   /** stores the outgoing edges for each node, that shall be considered in the flow computation */
   std::vector< std::vector<int> >  out_edges_;
   /** stores the incoming edges for each node, that shall be considered in the flow computation */
   std::vector< std::vector<int> >  in_edges_;
   /** stores all (!) outgoing edges for each node */
   std::vector< std::vector<int> >  all_out_edges_;
   /** stores all (!) incoming edges for each node */
   std::vector< std::vector<int> >  all_in_edges_;

   /** vector of length of the number of edges storing the cost of each edge*/
   std::vector<double> 				cost;
   /** vector of length of the number of edges storing the capacity of each edge*/
   std::vector<int>					capacity;

   /** stores the names of nodes */
   std::vector< std::string>  		node_names_;
   /** stores flags for each node (indicating whether it is an aggregation node, a sender or a normal node) */
   std::vector< int >				isSpecialNode_;
};

inline int Digraph::src_node( const int edge ) const
{
   assert( edge >= 0 );
   assert( edge < num_edges_ );
   assert( num_edges_ == int(src_.size()) );
   return src_[edge];
}

inline int Digraph::tgt_node( const int edge )const
{
   assert( edge >= 0 );
   assert( edge < num_edges_ );
   assert( num_edges_ == int(tgt_.size()) );
   return tgt_[edge];
}

inline const std::vector<int>& Digraph::out_edges( const int node ) const
{
   assert( node >= 0 );
   assert( node < num_nodes_ );
   assert( num_nodes_ == int(out_edges_.size()) );
   return out_edges_[node];
}


inline const std::vector<int>& Digraph::in_edges( const int node ) const
{
   assert( node >= 0 );
   assert( node < num_nodes_ );
   assert( num_nodes_ == int(in_edges_.size()) );
   return in_edges_[node];
}

inline const std::vector<int>& Digraph::all_out_edges( const int node ) const
{
   assert( node >= 0 );
   assert( node < num_nodes_ );
   assert( num_nodes_ == int(out_edges_.size()) );
   return all_out_edges_[node];
}


inline const std::vector<int>& Digraph::all_in_edges( const int node ) const
{
   assert( node >= 0 );
   assert( node < num_nodes_ );
   assert( num_nodes_ == int(in_edges_.size()) );
   return all_in_edges_[node];
}

inline bool Digraph::isAggregationNode(int nodeId) const
{
	return (this->isSpecialNode_[nodeId] & AGGREGATION_NODE_FLAG) == AGGREGATION_NODE_FLAG;
}

inline bool Digraph::isSendingNode(int nodeId) const
{
	return (this->isSpecialNode_[nodeId] & SENDING_NODE_FLAG) == SENDING_NODE_FLAG;
}

inline const std::string& Digraph::get_node_name (const int node) const
{
	return this->node_names_[node];
}

inline double Digraph::get_cost (const int edge) const
{
	return this->cost[edge];
}

inline int Digraph::get_capacity (const int edge) const
{
	return this->capacity[edge];
}

inline int Digraph::isSpecialNode(const int nodeId) const
{
	return isSpecialNode_[nodeId];
}


#endif
