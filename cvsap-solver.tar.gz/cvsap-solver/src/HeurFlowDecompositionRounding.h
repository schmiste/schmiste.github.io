/**@file   HeurFlowDecompositionRounding.h
 * @ingroup PRIMALHEURISTICS
 * @brief	Header for the Flow Decomposition Rounding Heuristic for CVSAP
 * @author Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 *
 */

/*---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8----+----9----+----0----+----1----+----2*/

#ifndef __SCIP_HEUR_FLOW_DECOMP_ROUNDING_H__
#define __SCIP_HEUR_FLOW_DECOMP_ROUNDING_H__


#include "scip/scip.h"
#include "CVSAPData.h"
#include <set>


#ifdef __cplusplus
extern "C" {
#endif

/**
 *
 * @param scip	pointer to SCIP data structure
 * @param data	pointer to the solver's main data structure
 * @return	SCIP_OKAY if everything went fine and an error code otherwise
 */
extern
SCIP_RETCODE SCIPincludeHeurFlowDecompositionRounding(
   SCIP*                 scip,                /**< SCIP data structure */
   CVSAPData* 			 data
   );

#ifdef __cplusplus
}
#endif

#endif
