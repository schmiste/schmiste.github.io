#ifndef PARAMETERS_H
#define PARAMETERS_H

#include <vector>
#include <set>
#include <map>
#include <string>

using namespace std;


struct Parameters{

	int SCALE;
	int nest_depth;
	bool use_creep;
	int max_cuts_before_lp_recalculation;
	bool add_sender_cuts_to_global_pool;
	bool add_aggregation_cuts_to_global_pool;
	double threshold_of_absorbed_flow_to_start_aggregation_cuts;

	int numberOfThreads;
	bool integralFlow;
	bool separateTerminals;

	bool debug_model_construction;
	bool debug_threading;
	bool debug_ConnectivityHandler;
	bool debug_connectivity_heuristic;
	bool debug_heuristic_flowdecoround;

	int maxNumberOfIterationsSolutionPolishing;

	Parameters();

	Parameters( 	int SCALE,
					int nest_depth,
					bool use_creep,
					bool separateTerminals,
					int max_cuts_before_lp_recalculation,
					bool add_sender_cuts_to_global_pool,
					bool add_aggregation_cuts_to_global_pool,
					double threshold_of_absorbed_flow_to_start_aggregation_cuts,
					int numberOfThreads,
					bool integralFlow,
					bool debug_threading,
					bool debug_model_construction,
					bool debug_SCutHandler,
					bool debug_connectivity_heuristic_,
					bool debug_heuristic_flowdecoround_,
					int maxNumberOfIterationsSolutionPolishing_);

	bool isAddAggregationCutsToGlobalPool() const;
	void setAddAggregationCutsToGlobalPool(bool addAggregationCutsToGlobalPool);
	bool isAddSenderCutsToGlobalPool() const;
	void setAddSenderCutsToGlobalPool(bool addSenderCutsToGlobalPool);
	bool isDebugConnectivityHeuristic() const;
	void setDebugConnectivityHeuristic(bool debugConnectivityHeuristic);
	bool isDebugConnectivityHandler() const;
	void setDebugConnectivityHandler(bool debugConnectivityHandler);
	bool isDebugModelConstruction() const;
	void setDebugModelConstruction(bool debugModelConstruction);
	bool isDebugThreading() const;
	void setDebugThreading(bool debugThreading);
	bool isIntegralFlow() const;
	void setIntegralFlow(bool integralFlow);
	int getMaxCutsBeforeLpRecalculation() const;
	void setMaxCutsBeforeLpRecalculation(int maxCutsBeforeLpRecalculation);
	int getNestDepth() const;
	void setNestDepth(int nestDepth);
	int getNumberOfThreads() const;
	void setNumberOfThreads(int numberOfThreads);
	int getScale() const;
	void setScale(int scale);
	bool isSeparateTerminals() const;
	void setSeparateTerminals(bool separateTerminals);
	double getThresholdOfAbsorbedFlowToStartAggregationCuts() const;
	void setThresholdOfAbsorbedFlowToStartAggregationCuts(
			double thresholdOfAbsorbedFlowToStartAggregationCuts);
	bool isUseCreep() const;
	void setUseCreep(bool useCreep);
	bool isDebugHeuristicFlowdecoround() const;
	void setDebugHeuristicFlowdecoround(bool debugHeuristicFlowdecoround);
	int getMaxNumberOfIterationsSolutionPolishing() const;
	void setMaxNumberOfIterationsSolutionPolishing(
			int maxNumberOfIterationsSolutionPolishing);
};



#endif
