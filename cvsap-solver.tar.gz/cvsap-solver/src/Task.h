#ifndef TASK_H
#define TASK_H

struct Task{
	int source;
	bool isAggregationNode;
	int cutoff;
};

#endif
