
#ifndef VA_H
#define VA_H

#include <vector>
#include <set>
#include <map>
#include <string>

using namespace std;

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Data structure representing a virtual arborescence, i.e. a rooted virtual tree where edges
 * 			represent paths.
 */
class VA{
public:
	/**
	 * adds a terminal to the VA
	 * @param nodeId	node id in the underlying graph
	 */
	void addTerminal(int nodeId);

	/**
	 * adds a steiner node to the VA
	 * @param nodeId	node id in the underlying graph
	 */
	void addSteinerNode(int nodeId);

	/**
	 * sets the root
	 * @param nodeId 	node id in the underlying graph
	 */
	void setRoot(int nodeId);

	/**
	 * adds a virtual edge to the VA
	 *
	 * @param head	head of the virtual edge (node id in the underlying graph)
	 * @param tail	tail of the virtual edge (node id in the underlying graph)
	 * @param path	list of edges in the underlying graph leading from the head to the tail node
	 */
	void addVirtualEdge(int head, int tail, const vector<int>& path);

	/**
	 * resets the data structure
	 */
	void cleanUp();

	/** root of the VA (node id) */
	int root;

	/** set of terminals contained in the VA*/
	set<int> terminals;

	/** set of steiner nodes contained in the VA*/
	set<int> steinerNodes;

	/**	for each contained terminal and steiner node, this map yields the node the node is connected to */
	map<int, int> 			vEdges;

	/** for each contained terminal and steiner node, this map yields the path in the underlying graph used
	 * 	to connect this node to the node specified by vEdges */
	map<int, vector<int> > paths;

	/**
	 * empty constructor
	 */
	VA();
};



#endif
