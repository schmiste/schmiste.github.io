#ifndef RECEIVER_CONFIGURATION_H
#define RECEIVER_CONFIGURATION_H

#include <vector>
#include <limits>
#include <string>
#include <map>

#include "objscip/objscip.h"

using namespace std;

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Data structure describing a receiver configuration.
 */
struct ReceiverConfiguration{

	/**
	 *
	 * @param name	name of the receiver configuration
	 * @param cost	cost for enabling this receiver configuration
	 */
	ReceiverConfiguration(string name, double cost);

	/**
	 * @return	returns the set of receivers that are enabled when this receiver configuration is chosen
	 */
	const vector<int>& get_receivers() const;

	/**
	 * returns capacity of node contained in this receiver configuration, if this configuration is enabled
	 *
	 * @param receiver	node id which is contained in this configuration
	 * @return	the integral capacity
	 */
	int get_receiver_capacity(int receiver) const;

	/**
	 * @return	cost for activating this receiver configuration
	 */
	double get_cost() const;

	/**
	 * @return 	name of this receiver configuration
	 */
	const string& get_name() const;

	/**
	 * adds a receiver to this configuration
	 *
	 * @param nodeId	node id in the underlying graph to add to the receiver configuration
	 * @param capacity	capacity of the node to add, when this receiver configuration is enabled
	 */
	void add_new_receiver(int nodeId, int capacity);

	/**
	 * @param nodeId	node id
	 * @return	whether this node is contained in the receiver configuration
	 */
	bool contains_receiver(int nodeId) const;



private:
	/** name of the receiver configuration */
	std::string name;
	/** cost of the receiver configuration*/
	double	cost;
	/** list of receivers, i.e. node ids in the underlying graph, that are contained within this configuration*/
	std::vector<int> receivers;
	/** map of node id (that must be contained within this configuration) to its capacitiy within this configuration*/
	std::map<int, int> receiver_capacities;
};


#endif
