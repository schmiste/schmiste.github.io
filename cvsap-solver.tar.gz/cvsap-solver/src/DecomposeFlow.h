/**
 * @file 	DecomposeFlow.h
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Header of the Algorithm to Decompose a solution of the Integer Program into a Virtual Arborescence
 */

#ifndef DECOMPOSE_FLOW_H
#define DECOMPOSE_FLOW_H

#include "VA.h"
#include "CVSAPData.h"

#include <vector>

#include <scip/scip.h>

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Decomposes a given IP solution into a Virtual Arborescence.
 */
class IPSolutionDecomposeFlow{


public:
	/**
	 * Creates a new Object to Decompose an IP solution
	 *
	 * @param scip	SCIP data structure pointer
	 * @param data	reference on the CVSAPData
	 */
	IPSolutionDecomposeFlow(SCIP* scip, CVSAPData& data);

	/**
	 * Reads data from a solution (most probably the best solution)
	 * @param solution 	A SCIP solution to our IP formulation
	 */
	void readDataFromSolution(SCIP_SOL* solution);

	/**
	 * starts the decomposition algorithm and returns the constructed virtual arborescence
	 * @return	the resulting virtual arborescence
	 */
	VA* constructVA();

private:


	/**
	 * Performs a (breadth-first) search for determining connectivity between startNode and endNode in the graph induced
	 * by the current flow.
	 * Note that after performing this check, the vector of predecessors gives a path from startNode to endNode if such
	 * a path exists.
	 *
	 * @param startNode	id in the underlying graph of the node the path shall start with
	 * @param endNode	id in the underlying graph of the node the path shall end with
	 * @return	true if a path exists, otherwise false
	 */
	bool checkConnectivity(int startNode, int endNode);

	/**
	 * Using a previous search (see checkConnectivity), this function reconstructs the path from startNode to endNode using
	 * the predecessor entries.
	 *
	 * @param startNode id in the underlying graph of the node the path shall start with
	 * @param endNode	id in the underlying graph of the node the path shall end with
	 * @param path		reference on vector object to store the path
	 */
	void getPath(int startNode, int endNode, vector<int>& path);


	/**
	 * resets all data structures, including the VA
	 */
	void cleanUp();

	/** pointer to the SCIP data structure*/
	SCIP* scip;
	/** set of all terminals*/
	set<int> terminals;
	/** set of all activated aggregation nodes (after reading a solution)*/
	set<int> aggregationNodes;
	/** the root */
	int root;

	CVSAPData& data;

	/** result virtual arborescence*/
	VA* va;

	/** debug flag*/
	bool debug;

	/** vector with the size of the number of nodes, storing edge ids for the bfs*/
	vector<int> predecessor;
	/** vector with the size of the number of edges, storing the (current) integral flow values*/
	vector<int> flow;

};

#endif
