#include "Parameters.h"

Parameters::Parameters()	:
	SCALE(10000),
	nest_depth(0),
	use_creep(false),
	max_cuts_before_lp_recalculation(10000),
	add_sender_cuts_to_global_pool(false),
	add_aggregation_cuts_to_global_pool(false),
	threshold_of_absorbed_flow_to_start_aggregation_cuts(false),
	numberOfThreads(1),
	integralFlow(true),
	separateTerminals(false),
	debug_model_construction(false),
	debug_threading(false),
	debug_ConnectivityHandler(false),
	debug_connectivity_heuristic(false),
	debug_heuristic_flowdecoround(false),
	maxNumberOfIterationsSolutionPolishing(1000)
{}

Parameters::Parameters( 	int SCALE_,
							int nest_depth_,
							bool use_creep_,
							bool separateTerminals_,
							int max_cuts_before_lp_recalculation_,
							bool add_sender_cuts_to_global_pool_,
							bool add_aggregation_cuts_to_global_pool_,
							double threshold_of_absorbed_flow_to_start_aggregation_cuts_,
							int numberOfThreads_,
							bool integralFlow_,
							bool debug_threading_,
							bool debug_model_construction_,
							bool debug_ConnectivityHandler_,
							bool debug_connectivity_heuristic_,
							bool debug_heuristic_flowdecoround_,
							int maxNumberOfIterationsSolutionPolishing_)
					: 	SCALE(SCALE_),
					  	nest_depth(nest_depth_),
					  	use_creep(use_creep_),
					  	max_cuts_before_lp_recalculation(max_cuts_before_lp_recalculation_),
					  	add_sender_cuts_to_global_pool(add_sender_cuts_to_global_pool_),
					  	add_aggregation_cuts_to_global_pool(add_aggregation_cuts_to_global_pool_),
					  	threshold_of_absorbed_flow_to_start_aggregation_cuts(threshold_of_absorbed_flow_to_start_aggregation_cuts_),
					  	numberOfThreads(numberOfThreads_),
					  	integralFlow(integralFlow_),
					  	separateTerminals(separateTerminals_),
					  	debug_model_construction(debug_model_construction_),
					  	debug_threading(debug_threading_),
					  	debug_ConnectivityHandler(debug_ConnectivityHandler_),
					  	debug_connectivity_heuristic(debug_connectivity_heuristic_),
					  	debug_heuristic_flowdecoround(debug_heuristic_flowdecoround_),
					  	maxNumberOfIterationsSolutionPolishing(maxNumberOfIterationsSolutionPolishing_)
{}

bool Parameters::isAddAggregationCutsToGlobalPool() const {
	return add_aggregation_cuts_to_global_pool;
}

void Parameters::setAddAggregationCutsToGlobalPool(
		bool addAggregationCutsToGlobalPool) {
	add_aggregation_cuts_to_global_pool = addAggregationCutsToGlobalPool;
}

bool Parameters::isAddSenderCutsToGlobalPool() const {
	return add_sender_cuts_to_global_pool;
}

void Parameters::setAddSenderCutsToGlobalPool(bool addSenderCutsToGlobalPool) {
	add_sender_cuts_to_global_pool = addSenderCutsToGlobalPool;
}

bool Parameters::isDebugConnectivityHeuristic() const {
	return debug_connectivity_heuristic;
}

void Parameters::setDebugConnectivityHeuristic(
		bool debugConnectivityHeuristic) {
	debug_connectivity_heuristic = debugConnectivityHeuristic;
}

bool Parameters::isDebugConnectivityHandler() const {
	return debug_ConnectivityHandler;
}

void Parameters::setDebugConnectivityHandler(bool debugConnectivityHandler) {
	debug_ConnectivityHandler = debugConnectivityHandler;
}

bool Parameters::isDebugModelConstruction() const {
	return debug_model_construction;
}

void Parameters::setDebugModelConstruction(bool debugModelConstruction) {
	debug_model_construction = debugModelConstruction;
}

bool Parameters::isDebugThreading() const {
	return debug_threading;
}

void Parameters::setDebugThreading(bool debugThreading) {
	debug_threading = debugThreading;
}

bool Parameters::isIntegralFlow() const {
	return integralFlow;
}

void Parameters::setIntegralFlow(bool integralFlow_) {
	this->integralFlow = integralFlow;
}

int Parameters::getMaxCutsBeforeLpRecalculation() const {
	return max_cuts_before_lp_recalculation;
}

void Parameters::setMaxCutsBeforeLpRecalculation(
		int maxCutsBeforeLpRecalculation) {
	max_cuts_before_lp_recalculation = maxCutsBeforeLpRecalculation;
}

int Parameters::getNestDepth() const {
	return nest_depth;
}

void Parameters::setNestDepth(int nestDepth) {
	nest_depth = nestDepth;
}

int Parameters::getNumberOfThreads() const {
	return numberOfThreads;
}

void Parameters::setNumberOfThreads(int numberOfThreads_) {
	this->numberOfThreads = numberOfThreads;
}

int Parameters::getScale() const {
	return SCALE;
}

void Parameters::setScale(int scale) {
	SCALE = scale;
}

bool Parameters::isSeparateTerminals() const {
	return separateTerminals;
}

void Parameters::setSeparateTerminals(bool separateTerminals_) {
	this->separateTerminals = separateTerminals;
}

double Parameters::getThresholdOfAbsorbedFlowToStartAggregationCuts() const {
	return threshold_of_absorbed_flow_to_start_aggregation_cuts;
}

void Parameters::setThresholdOfAbsorbedFlowToStartAggregationCuts(
		double thresholdOfAbsorbedFlowToStartAggregationCuts) {
	threshold_of_absorbed_flow_to_start_aggregation_cuts =
			thresholdOfAbsorbedFlowToStartAggregationCuts;
}

bool Parameters::isUseCreep() const {
	return use_creep;
}

void Parameters::setUseCreep(bool useCreep) {
	use_creep = useCreep;
}

bool Parameters::isDebugHeuristicFlowdecoround() const {
	return debug_heuristic_flowdecoround;
}

void Parameters::setDebugHeuristicFlowdecoround(
		bool debugHeuristicFlowdecoround) {
	debug_heuristic_flowdecoround = debugHeuristicFlowdecoround;
}

int Parameters::getMaxNumberOfIterationsSolutionPolishing() const {
	return maxNumberOfIterationsSolutionPolishing;
}

void Parameters::setMaxNumberOfIterationsSolutionPolishing(
		int maxNumberOfIterationsSolutionPolishing_) {
	this->maxNumberOfIterationsSolutionPolishing =
			maxNumberOfIterationsSolutionPolishing_;
}

