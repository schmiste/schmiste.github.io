/**
 * @file 	CVSAPData.cpp
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Header for CVSAPData which stores all important problem and solver related informations
 */

#include <iostream>
#include <fstream>
#include <limits>
#include <set>
#include <algorithm>

#include "CVSAPData.h"
#include "objscip/objscip.h"
#include "objscip/objscipdefplugins.h"
#include "SeparationTask.h"

using namespace std;
using namespace scip;

CVSAPData::~CVSAPData()
{
}

CVSAPData::CVSAPData() :
		minNumberOfReceiverConfigurations_(-1),
		maxNumberOfReceiverConfigurations_(-1),
		maxAggregationNodeBugdet_(numeric_limits<double>::max()),
		graph_(),
		superSourceId_(-1),
		superSinkAggregationId_(-1),
		superSinkReceiverId_(-1),
		parameters(NULL),
		threadpool(NULL)
{
}

// returns the digraph
const Digraph& CVSAPData::graph() const {
	return graph_;
}


const std::vector<int>& CVSAPData::get_senders() const {
	return senders_;
}

const std::vector<int>& CVSAPData::get_aggregation_nodes() const {
	return aggregation_nodes_;
}

double CVSAPData::get_aggregation_installation_cost(int nodeId) {
	return agg_installation_costs_[nodeId];
}

// returns arc variable of e
SCIP_VAR* CVSAPData::arc_var(const int e) const {
	return arc_vars_[e];
}

// sets arc variable of e
void CVSAPData::set_arc_var(const int e, SCIP_VAR* var) {
	arc_vars_[e] = var;
}

// read data from file
int CVSAPData::read(const char* filename) {
	static const string SCENARIO_NAME = "SCENARIO_NAME";
	static const string MIN_NUMBER_ACTIVE_RECEIVER_CONFIGURATIONS =	"MIN_NUMBER_ACTIVE_RECEIVER_CONFIGURATIONS";
	static const string MAX_NUMBER_ACTIVE_RECEIVER_CONFIGURATIONS =	"MAX_NUMBER_ACTIVE_RECEIVER_CONFIGURATIONS";
	static const string MAX_BUDGET_AGGREGATION_INSTALLATION = "MAX_BUDGET_AGGREGATIOIN_INSTALLATION";
	static const string NAME_SSOURCE = "NAME_SSOURCE";
	static const string NAME_SSINK_AGGREGATION = "NAME_SSINK_AGGREGATION";
	static const string NAME_SSINK_RECEIVER = "NAME_SSINK_RECEIVER";
	static const string NORMAL_NODE = "N";
	static const string SENDING_NODE = "NS";
	static const string AGGREGATION_NODE = "NA";
	static const string SENDING_AGGREGATION_NODE = "NAS";
	static const string RECEIVING_NODE = "R";
	static const string EDGE = "E";
	static const string RCONF = "RCONF";
	static const string RCONF_END = "RCONF_END";

	ifstream file(filename);
	if (!file) {
		cerr << "Cannot open file " << filename << endl;
		return 1;
	}

	int number, capacity;
	double installCost, usageCost, budget;
	string name, tail, head;
	bool reading_rconf = false;
	ReceiverConfiguration currentRcvConf("____", -1.0);
	//add superSource and superSinks
	while (file) {

		//--------------------
		// Read keyword.
		//--------------------
		string key;
		file >> key;
		if(!reading_rconf)
		{
			if(key == SCENARIO_NAME)
			{
				file >> name;
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << number << endl;
				this->scenarioName_ = name;
			}
			else if (key == MIN_NUMBER_ACTIVE_RECEIVER_CONFIGURATIONS) {
				file >> number;
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << number << endl;
				this->minNumberOfReceiverConfigurations_ = number;
			}
			else if (key == MAX_NUMBER_ACTIVE_RECEIVER_CONFIGURATIONS) {
				file >> number;
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << number << endl;
				this->maxNumberOfReceiverConfigurations_ = number;
			}
			else if (key == MAX_BUDGET_AGGREGATION_INSTALLATION) {
				file >> budget;
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << budget << endl;
				this->maxAggregationNodeBugdet_ = budget;
			}
			else if (key == NAME_SSOURCE) {
				file >> name;
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << name << endl;
				this->sSourceName_ = name;
				this->superSourceId_ = graph_.add_node(name,1);
				if(parameters->isDebugModelConstruction()) cout << "SuperSourceId: "<< " " << this->superSourceId_ << endl;
				nodeNameToId_[name] = this->superSourceId_;
			}
			else if (key == NAME_SSINK_AGGREGATION) {
				file >> name;

				this->sSinkAggregationName_ = name;
				this->superSinkAggregationId_ = graph_.add_node(name,2);
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << name <<  " / " << this->superSinkAggregationId_ << endl;
				nodeNameToId_[name] = this->superSinkAggregationId_;
			}
			else if (key == NAME_SSINK_RECEIVER) {
				file >> name;

				this->sSinkReceiverName_ = name;
				this->superSinkReceiverId_ = graph_.add_node(name,3);
				if(parameters->isDebugModelConstruction()) cout << "READ: "<< key << " " << name << " / " << this->superSinkReceiverId_ << endl;
				nodeNameToId_[name] = this->superSinkReceiverId_;
			}
			else if (key == NORMAL_NODE) {
				file >> name;
				int id = graph_.add_node(name, NORMAL_NODE_FLAG);
				nodeNameToId_[name] = id;
			} else if (key == SENDING_NODE) {
				file >> name;
				int id = graph_.add_node(name,SENDING_NODE_FLAG);
				//add edge from super source to node
				int edgeId = graph_.add_edge(this->superSourceId_, id, 1, 0, false);
				this->edgeFromSuperSourceToSender[id] = edgeId;
				nodeNameToId_[name] = id;
				this->senders_.push_back(id);
			} else if (key == AGGREGATION_NODE) {
				file >> name >> capacity >> installCost >> usageCost;
				int id = graph_.add_node(name,AGGREGATION_NODE_FLAG);
				int edgeId = graph_.add_edge(id, this->superSinkAggregationId_, capacity, usageCost, false);
				edgeFromAggregationNodeToSinkAggregation[id] = edgeId;
				edgeId = graph_.add_edge(this->superSourceId_, id, 1.0, 0.0, false);
				edgeFromSuperSourceToAggregationNode[id] = edgeId;
				agg_installation_costs_[id] = installCost;
				this->aggregation_nodes_.push_back(id);
				this->agg_capacities_[id] = capacity;
				nodeNameToId_[name] = id;
			}
			else if (key == SENDING_AGGREGATION_NODE) {
//				cout << "Currently nodes both sending and aggregating flows are not supported." << endl;
//				exit(0);
				file >> name >> capacity >> installCost >> usageCost;
				int id = graph_.add_node(name,SENDING_NODE_FLAG | AGGREGATION_NODE_FLAG);
				int edgeId = graph_.add_edge(this->superSourceId_, id, 1, 0, false);
				this->edgeFromSuperSourceToSender[id] =  edgeId;
				edgeId = graph_.add_edge(id, this->superSinkAggregationId_, capacity, usageCost, false);
				edgeFromAggregationNodeToSinkAggregation[id] = edgeId;
				this->aggregation_nodes_.push_back(id);
				this->senders_.push_back(id);
				agg_installation_costs_[id] = installCost;
				this->agg_capacities_[id] = capacity;
				nodeNameToId_[name] = id;
			}
			else if (key == EDGE) {
				file >> tail >> head >> capacity >> usageCost;
				int source = this->nodeNameToId_[tail];
				int target = this->nodeNameToId_[head];
				graph_.add_edge(source, target, capacity, usageCost, true);
			}
			else if (key == RCONF)
			{
				file >> name >> installCost;
				currentRcvConf = ReceiverConfiguration(name, installCost);
				reading_rconf = true;
			}
			else {
				string dummy;
				getline(file, dummy);
			}
		}
		else
		{
			if(key == RECEIVING_NODE)
			{
				file >> name >> capacity;
				int receiverId = this->nodeNameToId_.at(name);
				if(parameters->isDebugModelConstruction()) cout << "ADDING RECEIVER: " << name << " / " << receiverId << "\n";
				currentRcvConf.add_new_receiver(this->nodeNameToId_[name], capacity);
			}
			else if(key == RCONF_END)
			{
				this->receiver_configurations_.push_back(currentRcvConf);
				reading_rconf = false;
			}
			else {
				string dummy;
				getline(file, dummy);
			}
		}
	}
	if(this->scenarioName_.length() == 0)
	{
		this->scenarioName_ = string(filename, strlen(filename)-5);
	}
	// pre-dimension arc variable arrays
	arc_vars_.resize(graph_.num_edges());
	for (int e = 0; e < graph_.num_edges(); ++e)
	{
		arc_vars_[e] = NULL;
	}
	return 0;
}

void CVSAPData::setParameters(Parameters* parameters_)
{
	this->parameters = parameters_;
}

const Parameters* CVSAPData::getParameters() const
{
	return this->parameters;
}

void CVSAPData::createVariables(SCIP* scip)
{
	createArcVariables(scip);
	createAggregationNodeVariables(scip);
	createReceiverConfigurationVariables(scip);
}

void CVSAPData::createArcVariables(SCIP* scip)
{
	for (int i = 0; i < graph_.num_edges(); ++i) {
		SCIP_VAR* var;

		char var_name[255];
		int src = graph_.src_node(i);
		int tgt = graph_.tgt_node(i);
		const std::string& tailName = graph_.get_node_name(src);
		const std::string& headName = graph_.get_node_name(tgt);

		double lB = 0.0;
		double uB = (double)(graph_.get_capacity(i));
		double cost = graph_.get_cost(i);
		if(src == this->superSourceId_  &&
				(((this->graph_.isSpecialNode(tgt) & AGGREGATION_NODE_FLAG) != AGGREGATION_NODE_FLAG)
						||
				 ((this->graph_.isSpecialNode(tgt) & SENDING_NODE_FLAG) == SENDING_NODE_FLAG))
				)
		{
			lB = 1.0;
		}

		SCIPsnprintf(var_name, 255, "f(%s,%s)", tailName.c_str(), headName.c_str());

		if(parameters->isIntegralFlow())
		{
			SCIPcreateVar(
				scip,
				&var, // returns new index
				var_name, // name
				lB, // lower bound
				uB, // upper bound
				cost, // objective
				SCIP_VARTYPE_INTEGER, // variable type
				true, // initial
				false, // forget the rest ...
				0, 0, 0, 0, 0);
		}
		else
		{
			SCIPcreateVar(
				scip,
				&var, // returns new index
				var_name, // name
				lB, // lower bound
				uB, // upper bound
				cost, // objective
				SCIP_VARTYPE_CONTINUOUS, // variable type
				true, // initial
				false, // forget the rest ...
				0, 0, 0, 0, 0);
		}


		SCIPaddVar(scip, var);

		set_arc_var(i, var);
	}
}

void CVSAPData::createAggregationNodeVariables(SCIP* scip)
{
	for (unsigned int i = 0; i < this->aggregation_nodes_.size(); ++i) {
		SCIP_VAR* var;

		char var_name[255];

		int aggNode = aggregation_nodes_[i];
		const std::string& nodeName = graph_.get_node_name(aggNode);
		SCIPsnprintf(var_name, 255, "chi_A(%s)", nodeName.c_str());

		double lowerBound = 0.0;
		double upperBound = 1.0;
		double cost = this->agg_installation_costs_[aggNode];

		SCIPcreateVar(scip, &var, // returns new index
				var_name, // name
				lowerBound, // lower bound
				upperBound, // upper bound
				cost, // objective
				SCIP_VARTYPE_BINARY, // variable type
				true, // initial
				false, // forget the rest ...
				0, 0, 0, 0, 0);

		SCIPaddVar(scip, var);

		chi_A[aggNode] = var;
		SCIPchgVarBranchPriority(scip, var, 100);
	}
	return;
}

void CVSAPData::createReceiverConfigurationVariables(SCIP* scip)
{
	receivingNodes.clear();
	for (unsigned int i = 0; i < this->receiver_configurations_.size(); ++i) {
		SCIP_VAR* var;

		char var_name[255];
		const ReceiverConfiguration& rcvConf = this->receiver_configurations_[i];
		const string& rcvConfName = rcvConf.get_name();
		SCIPsnprintf(var_name, 255, "chi_A(%s)", rcvConfName.c_str());

		double lowerBound = 0.0;
		double upperBound = 1.0;
		double cost = rcvConf.get_cost();

		if(parameters->isDebugModelConstruction()) cout << "introducing variable for receiver config " << rcvConfName << "\n";

		SCIPcreateVar(scip, &var, // returns new index
				var_name, // name
				lowerBound, // lower bound
				upperBound, // upper bound
				cost, // objective
				SCIP_VARTYPE_BINARY, // variable type
				true, // initial
				false, // forget the rest ...
				0, 0, 0, 0, 0);

		SCIPaddVar(scip, var);

		this->chi_R[i] = var;

		SCIPchgVarBranchPriority(scip, var, 200);

		const vector<int>& receiverInConfig = rcvConf.get_receivers();
		for(vector<int>::const_iterator it = rcvConf.get_receivers().begin(); it != rcvConf.get_receivers().end(); ++it)
		{
			if(parameters->isDebugModelConstruction()) cout << "\t" << graph_.get_node_name(*it) << "\n";
		}
		//add all receivers
		receivingNodes.insert(receiverInConfig.begin(), receiverInConfig.end());
	}
	if(parameters->isDebugModelConstruction()) cout << "receiving nodes: \n";
	for(set<int>::iterator it = receivingNodes.begin(); it != receivingNodes.end(); ++it)
	{
		if(parameters->isDebugModelConstruction()) cout << "\t" << graph_.get_node_name(*it) << "\n";
	}
	//create arcs from receivers to supersink
	for(set<int>::iterator receiverIt = receivingNodes.begin(); receiverIt != receivingNodes.end(); ++receiverIt)
	{

		double upperBound = 0.0;

		for(unsigned int i = 0; i < this->receiver_configurations_.size(); ++i)
		{
			vector<int>::const_iterator it = find(receiver_configurations_[i].get_receivers().begin(), receiver_configurations_[i].get_receivers().end(), *receiverIt);
			if(it != receiver_configurations_[i].get_receivers().end())
			{
				upperBound += receiver_configurations_[i].get_receiver_capacity(*receiverIt);
			}
		}

		int edgeId = graph_.add_edge(*receiverIt, this->superSinkReceiverId_, upperBound, 0, true);

		this->edgeFromReceiverNodeToSinkReceiver[*receiverIt] = edgeId;

		SCIP_VAR* var;

		char var_name[255];
		const std::string& nameOfReceiver = graph_.get_node_name(*receiverIt);
		SCIPsnprintf(var_name, 255, "f(%s,%s)", nameOfReceiver.c_str(), this->sSinkReceiverName_.c_str());

		double lowerBound = 0.0;


		double cost = 0;

		if(parameters->isIntegralFlow())
		{
			SCIPcreateVar(scip, &var, // returns new index
				var_name, // name
				lowerBound, // lower bound
				upperBound, // upper bound
				cost, // objective
				SCIP_VARTYPE_INTEGER, // variable type
				true, // initial
				false, // forget the rest ...
				0, 0, 0, 0, 0);
		}
		else
		{
			SCIPcreateVar(scip, &var, // returns new index
				var_name, // name
				lowerBound, // lower bound
				upperBound, // upper bound
				cost, // objective
				SCIP_VARTYPE_CONTINUOUS, // variable type
				true, // initial
				false, // forget the rest ...
				0, 0, 0, 0, 0);
		}

		SCIPaddVar(scip, var);
		arc_vars_.push_back(0);
		this->set_arc_var(edgeId, var);
	}
	return;
}

int CVSAPData::getSuperSinkReceiverId() const
{
	return this->superSinkReceiverId_;
}

int CVSAPData::getSuperSinkAggregationId() const
{
	return this->superSinkAggregationId_;
}

int CVSAPData::getSuperSourceId() const
{
	return this->superSourceId_;
}

const std::vector<ReceiverConfiguration>& CVSAPData::getReceiverConfigurations() const
{
	return this->receiver_configurations_;
}

void CVSAPData::includeConstraint_FlowPreservationAtNodes(SCIP* scip)
{
	for (int node = 0; node < graph_.num_nodes(); ++node)
	{
		//flow preservation shall not hold at the supersource and the supersinks
		if(node == this->superSinkAggregationId_ || node == this->superSinkReceiverId_ || node == this->superSourceId_)
		{
			continue;
		}
		const std::string& nameOfNode = graph_.get_node_name(node);
		SCIP_CONS* con = NULL;
		char con_name[255];
		SCIPsnprintf(con_name, 255, "flow_preservation_at_nodes(%s)", nameOfNode.c_str());

		SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
		0, /* lhs */
		0, /* rhs */
		true, /* initial */
		false, /* separate */
		true, /* enforce */
		true, /* check */
		true, /* propagate */
		false, /* local */
		false, /* modifiable */
		false, /* dynamic */
		false, /* removable */
		false); /* stickingatnode */


		//consider ALL outgoing and ALL incoming edges
		const vector<int>& outgoing_edges = graph_.all_out_edges(node);
		const vector<int>& incoming_edges = graph_.all_in_edges(node);

		std::vector<int>::const_iterator edge_it;
		for (edge_it = incoming_edges.begin(); edge_it != incoming_edges.end(); ++edge_it) {
			SCIPaddCoefLinear(scip, con, this->arc_var(*edge_it), -1.0);
		}
		for (edge_it = outgoing_edges.begin(); edge_it != outgoing_edges.end(); ++edge_it) {
			SCIPaddCoefLinear(scip, con, this->arc_var(*edge_it), 1.0);
		}

		SCIPaddCons(scip, con);
		SCIPreleaseCons(scip, &con);
	}
}

void CVSAPData::includeConstraint_SetFlowFromSuperSourceToAggregationNode(SCIP* scip)
{
	for(std::map<int,int>::iterator it = edgeFromSuperSourceToAggregationNode.begin();
			it != edgeFromSuperSourceToAggregationNode.end();
			++it)
	{

		const std::string& nameOfNode = graph_.get_node_name(it->first);
		SCIP_CONS* con = NULL;
		char con_name[255];
		SCIPsnprintf(con_name, 255, "flow_from_supersource_to_aggregationnode(%s)", nameOfNode.c_str());

		SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
		0, /* lhs */
		0, /* rhs */
		true, /* initial */
		false, /* separate */
		true, /* enforce */
		true, /* check */
		true, /* propagate */
		false, /* local */
		false, /* modifiable */
		false, /* dynamic */
		false, /* removable */
		false); /* stickingatnode */

		SCIPaddCoefLinear(scip, con, this->chi_A[it->first], -1.0);
		SCIPaddCoefLinear(scip, con, this->arc_var(it->second), 1.0);

		SCIPaddCons(scip, con);
		SCIPreleaseCons(scip, &con);
	}
}

void CVSAPData::includeConstraint_ActivatedAggregationNodesForwardFlow(SCIP* scip)
{
	for (vector<int>::const_iterator aggNodeIt = aggregation_nodes_.begin(); aggNodeIt != aggregation_nodes_.end(); ++aggNodeIt)
	{

		//consider all outgoing edges BUT the edge to the superSinkAggregation
		const vector<int>& outgoing_edges = graph_.out_edges(*aggNodeIt);
		const std::string& nameOfNode = graph_.get_node_name(*aggNodeIt);
		SCIP_CONS* con = NULL;
		char con_name[255];
		SCIPsnprintf(con_name, 255, "each_activated_aggregation_node_forwards_flow(%s)", nameOfNode.c_str());

		SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
		0, /* lhs */
		this->senders_.size(), /* rhs */
		true, /* initial */
		false, /* separate */
		true, /* enforce */
		true, /* check */
		true, /* propagate */
		false, /* local */
		false, /* modifiable */
		false, /* dynamic */
		false, /* removable */
		false); /* stickingatnode */

		//add outgoing flows with positive weight
		std::vector<int>::const_iterator edge_it;
		for (edge_it = outgoing_edges.begin(); edge_it != outgoing_edges.end(); ++edge_it) {
			SCIPaddCoefLinear(scip, con, this->arc_var(*edge_it), 1.0);
		}

		//subtract the decision variable of the aggregation node
		SCIPaddCoefLinear(scip, con, this->chi_A.at(*aggNodeIt), -1.0);

		SCIPaddCons(scip, con);
		SCIPreleaseCons(scip, &con);
	}
}

void CVSAPData::includeConstraint_CapacityIsNotViolatedReceiver(SCIP* scip)
{
	for(set<int>::const_iterator receiverIt = receivingNodes.begin(); receiverIt != receivingNodes.end(); ++receiverIt)
	{
		SCIP_CONS* con = NULL;
		char con_name[255];
		const std::string& nameOfNode = graph_.get_node_name(*receiverIt);
		SCIPsnprintf(con_name, 255, "capacity_is_not_violated_receiver(%s)", nameOfNode.c_str());

		SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
		-SCIPinfinity(scip), /* lhs */
		0, /* rhs */
		true, /* initial */
		false, /* separate */
		true, /* enforce */
		true, /* check */
		true, /* propagate */
		false, /* local */
		false, /* modifiable */
		false, /* dynamic */
		false, /* removable */
		false); /* stickingatnode */

		const vector<int>& outgoing_edges = graph_.out_edges(*receiverIt);
		std::vector<int>::const_iterator edge_it;
		//search for the edge to the receiverSuperSink and add it
		for (edge_it = outgoing_edges.begin(); edge_it != outgoing_edges.end(); ++edge_it) {
			if(graph_.tgt_node(*edge_it) == this->superSinkReceiverId_)
			{
				SCIPaddCoefLinear(scip, con, this->arc_var(*edge_it), 1.0);
				break;
			}
		}

		for(unsigned int i = 0; i < this->receiver_configurations_.size(); ++i)
		{
			if((receiver_configurations_[i]).contains_receiver(*receiverIt))
			{
				SCIPaddCoefLinear(scip, con, this->chi_R[i], -(receiver_configurations_[i]).get_receiver_capacity(*receiverIt));
			}
		}

		SCIPaddCons(scip, con);
		SCIPreleaseCons(scip, &con);
	}
}

void CVSAPData::includeConstraint_CapacityIsNotViolatedAggregationNode(SCIP* scip)
{
	for(unsigned int i = 0; i < this->aggregation_nodes_.size(); ++i)
	{
		int aggNode = this->aggregation_nodes_[i];
		SCIP_CONS* con = NULL;
		char con_name[255];
		const std::string& nameOfNode = graph_.get_node_name(aggNode);
		SCIPsnprintf(con_name, 255, "capacity_is_not_violated_aggregation_node(%s)", nameOfNode.c_str());

		SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
				-SCIPinfinity(scip), /* lhs */
				0, /* rhs */
				true, /* initial */
				false, /* separate */
				true, /* enforce */
				true, /* check */
				true, /* propagate */
				false, /* local */
				false, /* modifiable */
				false, /* dynamic */
				false, /* removable */
				false); /* stickingatnode */

		const vector<int>& outgoing_edges = graph_.all_out_edges(aggNode);
		std::vector<int>::const_iterator edge_it;
		if(parameters->isDebugModelConstruction()) cout << "AGGREGATION CONSTRAINT!\n\n\n";
		//search for the edge to the aggregationSuperSink and add it
		for (edge_it = outgoing_edges.begin(); edge_it != outgoing_edges.end(); ++edge_it) {
			if(graph_.tgt_node(*edge_it) == this->superSinkAggregationId_)
			{
				SCIPaddCoefLinear(scip, con, this->arc_var(*edge_it), 1.0);
				if(parameters->isDebugModelConstruction()) cout << "FOUND IT!";
				if(parameters->isDebugModelConstruction()) cout << "edge: " << graph_.src_node(*edge_it) << " -> " << graph_.tgt_node(*edge_it) << "\n";
				break;
			}
		}

		if(parameters->isDebugModelConstruction()) cout << "max_capacity " << -agg_capacities_[aggNode]  << "\n";

		SCIPaddCoefLinear(scip, con, this->chi_A[aggregation_nodes_[i]], -agg_capacities_[aggNode]);

		SCIPaddCons(scip, con);
		SCIPreleaseCons(scip, &con);

	}
}

void CVSAPData::includeConstraint_BoundAllowedNumberOfReceiverConfiguration(SCIP* scip)
{
	SCIP_CONS* con = NULL;
	char con_name[255] = "bound_allowed_number_of_receiver_configurations";

	SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
			0, /* lhs */
			this->maxNumberOfReceiverConfigurations_, /* rhs */
			true, /* initial */
			false, /* separate */
			true, /* enforce */
			true, /* check */
			true, /* propagate */
			false, /* local */
			false, /* modifiable */
			false, /* dynamic */
			false, /* removable */
			false); /* stickingatnode */

	if(con == NULL)
		assert(false);

	for(unsigned int i = 0; i < this->receiver_configurations_.size(); ++i)
	{
		SCIPaddCoefLinear(scip, con, this->chi_R[i], 1.0);
	}

	SCIPaddCons(scip, con);
	SCIPreleaseCons(scip, &con);
}


void CVSAPData::includeConstraint_BoundCostsForInstallingAggregationNodes(SCIP* scip)
{
	SCIP_CONS* con = NULL;
	char con_name[255] = "bound_allowed_number_of_receiver_configurations";

	SCIPcreateConsLinear(scip, &con, con_name, 0, 0, 0,
			0.0, /* lhs */
			this->maxAggregationNodeBugdet_, /* rhs */
			true, /* initial */
			false, /* separate */
			true, /* enforce */
			true, /* check */
			true, /* propagate */
			false, /* local */
			false, /* modifiable */
			false, /* dynamic */
			false, /* removable */
			false); /* stickingatnode */

	for(unsigned int i = 0; i < this->aggregation_nodes_.size(); ++i)
	{
		SCIPaddCoefLinear(scip, con, this->chi_A[aggregation_nodes_[i]], agg_installation_costs_.at(aggregation_nodes_[i]));
	}


	SCIPaddCons(scip, con);
	SCIPreleaseCons(scip, &con);
}

SCIP_VAR*	CVSAPData::get_chi_A(int nodeId) const
{
	return this->chi_A.at(nodeId);
}

bool CVSAPData::isAggregationNode(int nodeId) const
{
	return (this->chi_A.find(nodeId) != chi_A.end());
}

const ReceiverConfiguration& CVSAPData::getReceiverConfiguration(int id) const
{
	return this->receiver_configurations_[id];
}

SCIP_VAR* CVSAPData::get_chi_R(int id) const
{
	return this->chi_R.at(id);
}

int CVSAPData::get_edge_from_aggregation_node_to_aggregation_sink(int nodeId) const
{
	return this->edgeFromAggregationNodeToSinkAggregation.at(nodeId);
}


void CVSAPData::createThreadPool(SCIP* scip)
{
	this->threadpool = new MaxFlowThreadpool(parameters->getNumberOfThreads(), scip, this->graph_, this);
	//add tasks:
	if(parameters->isSeparateTerminals())
	{
		//tasks for senders are only added if they shall be separated
		for(unsigned int i = 0; i < this->senders_.size(); ++i)
		{
			vector<SeparationTask* >& finishedTasks = this->threadpool->getFinishedTasks();
			SeparationTask* task = new SeparationTask();
			task->source = senders_[i];
			task->isAggregationNode = false;
			task->cutoff = parameters->getScale();
			finishedTasks.push_back(task);
		}
	}
	for(unsigned int i = 0; i < this->aggregation_nodes_.size(); ++i)
	{
		vector<SeparationTask* >& finishedTasks = this->threadpool->getFinishedTasks();
		SeparationTask* task = new SeparationTask();
		task->source = aggregation_nodes_[i];
		task->isAggregationNode = true;
		task->cutoff = parameters->getScale();
		finishedTasks.push_back(task);
	}
	this->threadpool->createThreads();
}

MaxFlowThreadpool* CVSAPData::getPool()
{
	return this->threadpool;
}


const set<int>& CVSAPData::getReceivers() const
{
	return this->receivingNodes;
}

int CVSAPData::getEdgeFromReceiverToReceiverSink(int nodeId) const
{
	return this->edgeFromReceiverNodeToSinkReceiver.at(nodeId);
}

int CVSAPData::getEdgeFromSupersourceToNode(int node) const
{
	if(this->graph_.isSpecialNode(node) & SENDING_NODE_FLAG)
	{
		return this->edgeFromSuperSourceToSender.at(node);
	}
	else
		return this->edgeFromSuperSourceToAggregationNode.at(node);
}

const std::string& CVSAPData::getScenarioName() const
{
	return this->scenarioName_;
}

