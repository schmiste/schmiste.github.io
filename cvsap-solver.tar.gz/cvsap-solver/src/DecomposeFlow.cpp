/**
 * @file 	DecomposeFlow.cpp
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Implementation of the Algorithm to Decompose a solution of the Integer Program
 */

#include <iostream>
#include <vector>
#include <deque>
#include <limits>

#include "DecomposeFlow.h"
#include "Digraph.h"


IPSolutionDecomposeFlow::IPSolutionDecomposeFlow(SCIP* scip_, CVSAPData& data_)
	:
	scip(scip_),
	root(-1),
	data(data_),
	va(),
	debug(false)
{
	va = new VA();
}

VA* IPSolutionDecomposeFlow::constructVA()
{
	const Digraph& graph = data.graph();
	int edge = -1, edge_source, edge_target;

	bool found = false;
	vector<int> path;
	vector<int> pathPrimed;


	//initialise VSA with nodes
	va->setRoot(this->root);
	for(set<int>::iterator it = this->terminals.begin(); it != this->terminals.end(); ++it)
	{
		va->addTerminal(*it);
	}
	for(set<int>::iterator it = this->aggregationNodes.begin(); it != this->aggregationNodes.end(); ++it)
	{
		va->addSteinerNode(*it);
	}

	//sets storing the remaining activated seiner sites and the remaining terminals
	set<int> Shat(aggregationNodes);
	set<int> That(terminals);

 	if(this->debug) cout << "Decomposition started ..." << endl;
	while(!That.empty())
	{
		//choose a terminal
		int t = *(That.begin());
		That.erase(t);

		//look
		edge = data.getEdgeFromSupersourceToNode(t);
		//decrement flow
		flow[edge] = flow[edge] - 1;

 		if(this->debug) cout << "super source " << data.getSuperSourceId() << endl;
 		if(this->debug) cout << "super sink R " << data.getSuperSinkReceiverId() << endl;
 		if(this->debug) cout << "super sink A " << data.getSuperSinkAggregationId() << endl;

		for(int edgeIt = 0; edgeIt < graph.num_edges(); ++edgeIt)
		{
			//output current flow values
			if(flow[edgeIt] > 0)
				if(this->debug) cout << "edge " << edgeIt << " (" << graph.get_node_name(graph.src_node(edgeIt)) << "," << graph.get_node_name(graph.tgt_node(edgeIt)) << "): " << flow[edgeIt] << endl;
		}

		//try to find a path from t to the superSinkReceiver
		if(!checkConnectivity(t, data.getSuperSinkReceiverId()))
		{
			//if no such path exists either our algorithm is incorrect or the input was wrong
			if(this->debug) cout << "could not find a path towards the super sink receiver" << endl;
			assert(0);
		}

 		if(this->debug) cout << "found path from t "  << t << " towards super sink receiver "<< endl;
		//reconstruct path
 		this->getPath(t, data.getSuperSinkReceiverId(), path);

 		if(this->debug) cout << "path is: "<< endl;
		for(unsigned int k = 0; k < path.size(); ++k)
		{
 			if(this->debug) cout << "\tedge " << path[k] << " (" << graph.get_node_name(graph.src_node(path[k])) << "," <<  graph.get_node_name(graph.tgt_node(path[k])) << ") " << endl;
		}
 		if(this->debug) cout << endl;

 		if(this->debug) cout << "start processing path.." << endl;
 		for(unsigned int j = 0; j < path.size(); ++j)
		{
			edge = path[j];
			edge_source = graph.src_node(edge);
			edge_target = graph.tgt_node(edge);
 			if(this->debug) cout << "handling edge " << edge << " (" << edge_source << "," << edge_target << ") " << endl;
			//decrement flow
 			flow[edge] = flow[edge]-1;
			if(flow[edge] == 0)
			{
				//only if the flow on the current edge is zero (after decrementing) we need to check connectivity
				for(set<int>::iterator aggregationNode = Shat.begin(); aggregationNode != Shat.end(); ++aggregationNode)
				{
					//check connectivity for each aggregation node
					if(!checkConnectivity(*aggregationNode, data.getSuperSinkReceiverId()))
					{
						//connectivity is violated
 						if(this->debug) cout << "connectivity for " << *aggregationNode  << " is violated "<< endl;
						found = false;
						//construct a path from the current node towards the supersink for aggregation nodes
						if(checkConnectivity(edge_source, data.getSuperSinkAggregationId()))
						{
							//if such a path exists, then..
							this->getPath(edge_source, data.getSuperSinkAggregationId(), pathPrimed);
							found = true;
							//repair flow decrementation
							flow[edge] = flow[edge] + 1;
							flow[pathPrimed[0]] = flow[pathPrimed[0]]-1;
							//redirect path towards aggregation sink
							path.erase(path.begin()+j, path.end());
							path.insert(path.end(), pathPrimed.begin(), pathPrimed.end());
							//we do not need to check any other aggregation nodes
							break;
						}
						else
						{
							//no alternative path exists, should not happen
							if(this->debug) cout << "error!" << endl;
						}
						//if our algorithm failed, output some information
						if(found == false)
						{
							if(this->debug) cout << "did not find path to aggregation sink... :(!" << endl;
							for(int node = 0; node < graph.num_nodes(); ++node)
							{
								if(this->debug) cout << "predecessor[" << node << "] = " << predecessor[node] << endl;
							}
							assert(0);
						}
					}
				}
			}
		}
 		//the last edge
		edge = path[path.size()-1];
		edge_source = graph.src_node(edge);
		edge_target = graph.tgt_node(edge);
		if(edge_target == data.getSuperSinkAggregationId() && flow[edge] == 0)
		{
			//if the path ended in an aggregation node that now absorbs no more flow then
			//put this aggregation node in the set of terminals
			Shat.erase(edge_source);
			That.insert(edge_source);
		}
		//lastly: add arc to va corresponding to the
		va->addVirtualEdge(t, edge_target, path);
	}
 	if(this->debug) cout << "decompose flow terminated" << endl << endl;
	for(int edgeIt = 0; edgeIt < graph.num_edges(); ++edgeIt)
	{
		//output the flow on each edge to show that actually all flow has been removed
		if(this->debug) cout << "edgeIt " << edgeIt << " (" << graph.src_node(edgeIt) << "," << graph.tgt_node(edge) << "): " << flow[edgeIt] << endl;
	}
	return va;
}

//performs a simple breadth-first search
bool IPSolutionDecomposeFlow::checkConnectivity(int startNode, int endNode)
{
	for(unsigned int i = 0; i < predecessor.size(); ++i)
	{
		predecessor[i] = -1;
	}
	const Digraph& graph = data.graph();
	deque<int> Q;
	Q.push_front(startNode);
	int edge_target;
	predecessor[startNode] = graph.num_edges();
	while(!Q.empty())
	{
		int currentNode = Q.front();
		Q.pop_front();
		const std::vector<int>&  currentOutEdges = graph.all_out_edges(currentNode);
		for (unsigned int i=0; i< currentOutEdges.size(); ++i)
		{
			edge_target = graph.tgt_node(currentOutEdges[i]);
			if (predecessor[edge_target] == -1 && flow[currentOutEdges[i]] > 0)
			{
				predecessor[edge_target] = currentOutEdges[i];
				if(edge_target == endNode)
				{
					return true;
				}
				else
				{
					Q.push_back(edge_target);
				}
			}
		}
	}
	return false;
}

//uses the information stored in the predecessors to reconstruct the path found
//in a previous checkConnectivity call
void IPSolutionDecomposeFlow::getPath(int startNode, int endNode, vector<int>& path)
{
	path.clear();
	int currentNode = endNode;
	const Digraph& graph = data.graph();
	int edge;
	int edge_source;
	int edge_target;
	while ((edge = predecessor[currentNode]) != graph.num_edges())
	{
		edge_source = graph.src_node(edge);
		edge_target = graph.tgt_node(edge);
		if(edge_target == currentNode)
		{
			currentNode = edge_source;
			path.insert(path.begin(), edge);
			if(currentNode == startNode)
				return;
		}
		else if(edge_source == currentNode)
		{
			if(this->debug) cout << "edge was taken in wrong direction!" << endl;
		}
		else
		{
			if(this->debug) cout << "edge is not incident to node!" << endl;
		}
	}
}


void IPSolutionDecomposeFlow::readDataFromSolution(SCIP_SOL* bestSolution)
{
	this->cleanUp();
	//set internal terminals
	terminals.insert(data.get_senders().begin(), data.get_senders().end());

	//select active aggregation nodes
	const vector<int>& aggregationNodes_ = data.get_aggregation_nodes();
	for(unsigned int i = 0; i < aggregationNodes_.size(); ++i)
	{
		if(SCIPgetSolVal(scip, bestSolution, data.get_chi_A(aggregationNodes_[i])) >= 0.9999)
		{
			this->aggregationNodes.insert(aggregationNodes_[i]);
		}
		else if(SCIPgetSolVal(scip, bestSolution, data.get_chi_A(aggregationNodes_[i])) <= 0.0001)
		{
		}
		else
		{
			if(this->debug) cout << "chi_A had wrong value!" << SCIPgetSolVal(scip, bestSolution, data.get_chi_A(aggregationNodes_[i])) << endl;
			return;
		}
	}
	//lookup receiver
	if(data.getReceiverConfigurations().size() != 1)
	{
		if(this->debug) cout << "cannot handle more than one receiver configuration" << endl;
		return;
	}
	else
	{
		const ReceiverConfiguration& config = data.getReceiverConfiguration(0);
		if(config.get_receivers().size() != 1)
		{
			if(this->debug) cout << "receiver configuration should only contain a single receiver!" << endl;
			return;
		}
		int receiver = config.get_receivers()[0];
		this->root = receiver;
	}

	flow = vector<int>(data.graph().num_edges(), 0);
	predecessor = vector<int>(data.graph().num_nodes(),-1);
	//read the flow values
	for(int e = 0; e < data.graph().num_edges(); ++e)
	{
		double flowOnE = SCIPgetSolVal(scip, bestSolution, data.arc_var(e));
		if(fabs(round(flowOnE) - flowOnE) > 0.001)
		{
			if(this->debug) cout << "flow was not integral!" << endl;
			assert(0);
		}
		flow[e] = round(flowOnE);
	}
}

void IPSolutionDecomposeFlow::cleanUp()
{
	//clear all internal data structures
	this->terminals.clear();
	this->aggregationNodes.clear();
	this->root = -1;
	this->flow.clear();
	this->predecessor.clear();
	this->va->cleanUp();
}
