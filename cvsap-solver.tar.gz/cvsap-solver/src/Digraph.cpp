#include "Digraph.h"
#include <vector>



Digraph::Digraph():
   num_nodes_( 0 ),
   num_edges_( 0 ),
   tgt_(0),
   src_(0),
   out_edges_(),
   in_edges_(),
   all_out_edges_(),
   all_in_edges_(),
   cost(),
   capacity(),
   node_names_(),
   isSpecialNode_()
{}
   
int Digraph::num_nodes() const
{
   return num_nodes_;
}
   
int Digraph::num_edges() const 
{
   return num_edges_;
}
   
int Digraph::add_node(std::string nodeName, int specialNode)
{
   assert( num_nodes_ == int(out_edges_.size()) );
   assert( num_nodes_ == int(in_edges_.size()) );
   out_edges_.push_back( std::vector<int>() );
   in_edges_.push_back ( std::vector<int>() );
   all_out_edges_.push_back (std::vector<int>());
   all_in_edges_.push_back (std::vector<int>());
   node_names_.push_back(nodeName);
   isSpecialNode_.push_back(specialNode);
   return num_nodes_++;
}

int Digraph::add_edge( const int source_node, const int target_node, int capacity_, double cost_, bool includeInFlow)
{
   assert( source_node >= 0 );
   assert( target_node >= 0 );
   assert( source_node < num_nodes_ );
   assert( target_node < num_nodes_ );
   assert( num_edges_ == int(tgt_.size()) );
   assert( num_edges_ == int(src_.size()) );
   const int edge = num_edges_++;
   src_.push_back( source_node );
   tgt_.push_back( target_node );
   if(includeInFlow)
   {
	   out_edges_[source_node].push_back(edge);
	   in_edges_ [target_node].push_back(edge);
   }
   all_out_edges_[source_node].push_back(edge);
   all_in_edges_[target_node].push_back(edge);
   this->capacity.push_back(capacity_);
   this->cost.push_back(cost_);
   return edge;
}
