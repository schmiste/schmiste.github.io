#ifndef MAXFLOWWORKER_H
#define MAXFLOWWORKER_H

#include <vector>
//#include <thread>
//#include <mutex>
//#include <condition_variable>
#include <string>
#include <limits>
#include "Digraph.h"
#include "CVSAPData.h"

#include "SeparationTask.h"
#include "EdgeCut.h"
#include "MaxFlowThreadpool.h"

using namespace std;

class MaxFlowThreadpool;

struct CVSAPData;

class MaxFlowWorker {

public:
	/**
	 * Initializes the internal data structures.
	 *
	 * @param pool	Pointer to the threadpool
	 * @param name	Name of the worker, such that they can be distinguished
	 */
	MaxFlowWorker(MaxFlowThreadpool* pool, std::string name);

	/**
	 * Executes the given task and stores the generated cuts internally and notifies the MaxFlowThreadpool of
	 * the number of cuts generated.
	 * This function is called from within the thread corresponding to this worker, that is created within the MaxFlowThreadpool.
	 * @param task
	 */
	void work(SeparationTask* task);

	/**
	 * @return	whether this worker has finished generating cuts or not
	 */
	bool isFinished() const;

	/**
	 * sets the finish flag to false
	 */
	void setFinishToFalse();

	/**
	 * @return the number of generated cuts for the current LP
	 */
	int getNumberOfGeneratedCuts();

	/**
	 * @param index	must lie within 0 and getNumberOfGeneratedCuts()-1
	 * @return a reference to the edgecut at position index
	 */
	const EdgeCut* getEdgeCut(int index) const;

	/**	flag determining whether this worker has finished the generation of cuts */
	bool hasFinished;

	/**	name of the worker */
	std::string worker_name;

	/**	underlying graph */
	const Digraph& graph;

	/**	pointer to the solver's main data structure */
	const CVSAPData* data;

	/**
	 * 	pointer to the threadpool that uses this worker*/
	MaxFlowThreadpool* pool;

private:
	//members for internal flow calculation

	/**	number of nodes */
	int n;

	/**	number of edges */
	int m;

	/**	vector in which the ids of edges whose capacities have been adapted (for nested-cuts)
	 * are stored */
	vector<int> edgesWithChangedCapacities;
	/**	vector with the original capacities of edges, aligned with edgesWithChangedCapacities */
	vector<int> previousCapacities;

	/**
	 * Returns a pointer to an edgeCut stored within the vector edgeCuts such that edgeCuts[currentCutIndex] equals
	 * the returned pointer.
	 *
	 * @param source			source of the edge cut (node id in the underlying graph)
	 * @param isAggregationCut	whether this cut is for aggregation nodes
	 * @return	pointer to an EdgeCut object
	 */
	EdgeCut* getFreshEdgeCut(int source, bool isAggregationCut);

	/**	index of current edge cut object in the vector edgeCuts */
	int currentCutIndex;

	/**	stores the generated edgeCuts */
	vector< EdgeCut* > edgeCuts;

	/**	identifier for the capacities as read from the threadpool */
	int capacityTimeStamp;



	/**
	 * Controls the execution of the max flow computations and creates
	 * EdgeCut objects where violated inequalities are found.
	 * This function calls itself recursively for generating nested cuts.
	 *
	 * @param source		source node for the max flow computation
	 * @param tgt			target node for the max flow computation
	 * @param totalFlow		the amount of flow sent (during a previous iteration for nested cuts)
	 * @param cutoff		the amount of flow necessary, such that all inequalities hold
	 * @param current_depth	the depth when using neted cuts
	 * @param task			the task to execute
	 * @return	the number of generated cuts
	 */
	int checkFlowAndAddCutsIfNecessary(int source,
								  	  int tgt,
								  	  int& totalFlow,
								  	  int cutoff,
								  	  int current_depth,
								  	  SeparationTask* task);


	/** predecessor for each node, aligned with the ids of nodes */
	vector<int> predecessors;

	/** capacity for each edge, aligned with the ids of edges */
	vector<int> cap;

	/** the current flow for each edge, aligned with the ids of edges */
	vector<int> flow;

	/** list of edges in the original direction (used in many different contexts) */
	vector<int> forwardEdges;

	/** list of edges with reversed direction (used in many different contexts) */
	vector<int> reverseEdges;

	/**
	 * performs max flow computation using the private data structures
	 *
	 * @param source	source of the max flow computation
	 * @param target	target of the max flow computation
	 * @param total		flow already sent
	 * @param cutoff	amount of flow at which all inequalities hold
	 */
	void max_flow( const int 				 source,
				   const int               target,
				   int&                    total,
				   const int               cutoff = std::numeric_limits<int>::max() );
};








#endif
