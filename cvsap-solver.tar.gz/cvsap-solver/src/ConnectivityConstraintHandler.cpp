/**
 * @file	ConnectivityConstraintHandler.cpp
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Implementation of the Connectivity Constraint Separation
 *
 */

#include <iostream>
#include <fstream>
#include <queue>
#include <deque>
#include <bitset>
#include <string>
#include <math.h>
#include <algorithm>
#include <cmath>
#include <deque>
#include <stdio.h>
#include <cstdlib>

#include "ConnectivityConstraintHandler.h"
#include "EdgeCut.h"
#include "MaxFlowThreadpool.h"
#include "SeparationTask.h"
#include <ctime>
#include "scip/type_scip.h"


using namespace std;
using namespace scip;

/**
*	Data passed to the constraint handler upon invocation.
*/
struct SCIP_ConsData {
	CVSAPData* data;
};


	static const char* HANDLER_NAME = "ConnectivityConstraints";
	static const char* HANDLER_DESC = "Connectivity Constraint Handler";

/**
 * Checks whether the solution provided satisfies the connectivity constraints.
 *
 * @param scip	SCIP data structure
 * @param data	underlying graph
 * @param sol	proposed solution
 * @return  true if connectivity constraints are violated and false otherwise
 */
SCIP_Bool ConnectivityConstraintHandler::checkViolationOfConnectivityConstraints(	SCIP* scip, const CVSAPData* data, SCIP_SOL* sol)
{
	const Digraph& g = data->graph();
	const int m = g.num_edges();

	static vector<int> cap(m);
	static vector<int> predecessors(g.num_nodes(), -1);

	for (int n = 0; n < g.num_nodes(); ++n) {
		predecessors[n] = -1;
	}
	for (vector<int>::const_iterator it = data->get_senders().begin();
			it != data->get_senders().end(); ++it) {
	}

	for (int e = 0; e < m; ++e) {
		const double x = SCIPgetSolVal(scip, sol, data->arc_var(e));
		if(data->getParameters()->isDebugConnectivityHandler())
		{
			if (fabs(round(x) - x) > 0.001) {
				cout << SCIPvarGetName(data->arc_var(e)) << ": " << x << "\n";
			}
		}
		cap[e] = round(x);
	}

	//perform a reverse breadth first search from the super sink Receiver towards all nodes
	const int tgt = data->getSuperSinkReceiverId();
	deque<int> Q;
	Q.push_front(tgt);
	int edge_source;
	predecessors[tgt] = g.num_edges();
	while(!Q.empty())
	{
		int currentNode = Q.front();
		Q.pop_front();
		const std::vector<int>&  currentInEdges = g.all_in_edges(currentNode);
		for (unsigned int i=0; i< currentInEdges.size(); ++i)
		{
			edge_source = g.src_node(currentInEdges[i]);
			if (predecessors[edge_source] == -1 && cap[currentInEdges[i]] > 0)
			{
				predecessors[edge_source] = currentInEdges[i];
				Q.push_back(edge_source);
			}
		}
	}

	//we check for each aggregation node whether it was reached in the above reverse search, implying
	//that it can reach the super sink
	for (vector<int>::const_iterator aggIt =
			data->get_aggregation_nodes().begin();
			aggIt != data->get_aggregation_nodes().end(); ++aggIt) {
		if(SCIPgetSolVal(scip, sol, data->get_chi_A(*aggIt)) > 0.5)
		{
			//if the predecessor is -1 then it could not be reached and the solution is not feasible
			if(predecessors[*aggIt] == -1)
			{
				if(data->getParameters()->isDebugConnectivityHandler())
				{
					cout << "infeasible solution!" << endl;
				}
				return true;
			}
		}
	}

	if(data->getParameters()->isDebugConnectivityHandler())
	{
		cout << "feasible solution!" << endl;
	}
	return false;
}

/**
 * Given an abstract EdgeCut adds the Cut (w.r.t to the SCIP variables)
 *
 * @param scip		SCIP data structure
 * @param sol		current solution
 * @param graph
 * @param data
 * @param edgeCut	EdgeCut to add
 * @param cuts		reference to the global number of cuts (which is incremented by this method)
 * @return	SCIP_OKAY if everything went fine and otherwise the corresponding return code of the function called that failed
 */
SCIP_RETCODE ConnectivityConstraintHandler::createConstraintCallback(
			SCIP* scip,
			SCIP_SOL* sol,
			const Digraph& graph,
			const CVSAPData* data,
			const EdgeCut* edgeCut,
			int& cuts)
{
	++cuts;
	SCIP_ROW* row;
	static char name[255];
	sprintf(name, "cut_sender_%d", cuts);
	double lhs = 1;
	if(edgeCut->isAggregationCut())
	{
		lhs = 0;
	}
	SCIP_CALL(SCIPcreateEmptyRow(scip, &row, name, lhs, // lhs
				SCIPinfinity(scip), // rhs
				FALSE, FALSE, FALSE));

	SCIP_CALL(SCIPcacheRowExtensions(scip, row));


	const vector<int>& edgesInCut = edgeCut->getEdgesInCut();
	for(unsigned int i = 0; i < edgesInCut.size(); ++i)
	{
		SCIP_CALL(SCIPaddVarToRow(scip, row, data->arc_var(edgesInCut[i]), 1.0));
	}
	if(edgeCut->isAggregationCut())
	{
		SCIP_CALL(SCIPaddVarToRow(scip, row, data->get_chi_A(edgeCut->getSource()), -1.0));
	}
	SCIP_CALL(SCIPflushRowExtensions(scip, row));
	SCIP_CALL(SCIPaddCut(scip, sol, row, FALSE));
	SCIP_CALL(SCIPreleaseRow(scip, &row));
	return SCIP_OKAY;
}



/**
 * Separates Connectivity Inequalities, i.e. adds cuts corresponding to violated constraints if such exist.
 *
 * @param scip			SCIP data structure
 * @param conshdlr		the constraint handler itself
 * @param conss			array of constraints to process
 * @param nconss		number of constraints to process
 * @param nusefulconss	number of useful	 (non-obsolete) constraints to process
 * @param sol			primal solution that should be separated
 * @param result		pointer to store the result of the separation call
 * @return	SCIP_OKAY if everything went fine and otherwise the corresponding return code of the function called that failed
 */
SCIP_RETCODE ConnectivityConstraintHandler::separateConnectivityInequalities(
	SCIP* scip,
	SCIP_CONSHDLR* conshdlr,
	SCIP_CONS** conss,
	int nconss,
	int nusefulconss,
	SCIP_SOL* sol,
	SCIP_RESULT* result
) {
	assert(result != NULL);
	*result = SCIP_DIDNOTFIND;

	static int cuts = 0;

	for (int c = 0; c < nusefulconss; ++c) {

		// get required structures
		SCIP_CONSDATA* consdata = SCIPconsGetData(conss[c]);
		assert(consdata != NULL);
		CVSAPData* data = consdata->data;
		assert(data != NULL);

		// initialize data structured
		data->getPool()->resetNumberOfGeneratedCuts();
		data->getPool()->readCapacities(sol);
		// append previously finished tasks to open tasks
		deque<SeparationTask*>& tasks = data->getPool()->getTasks();
		tasks.insert(tasks.end(), data->getPool()->getFinishedTasks().begin(), data->getPool()->getFinishedTasks().end());
		//and clear finished tasks
		data->getPool()->getFinishedTasks().clear();


		for(unsigned int i = 0; i < tasks.size(); ++i)
		{
			if(tasks[i]->isAggregationNode)
			{
				const double chi_A = SCIPgetSolVal(scip, sol, data->get_chi_A(tasks[i]->source));
				const double flow_absorption = SCIPgetSolVal(scip, sol, data->arc_var(data->get_edge_from_aggregation_node_to_aggregation_sink(tasks[i]->source)));
				if(chi_A < 0.01 || flow_absorption < data->getParameters()->getThresholdOfAbsorbedFlowToStartAggregationCuts())
				{
					//remove tasks corresponding to aggregation nodes if the activation value is marginal or
					//if the amount of absorbed flow is low
					data->getPool()->getFinishedTasks().push_back(tasks[i]);
					tasks.erase(tasks.begin() + i);
				}
				else
				{
					//otherwise set the cutoff appropriately
					tasks[i]->cutoff = ceil(chi_A * data->getParameters()->getScale());
				}
			}
		}
		if(data->getParameters()->isDebugConnectivityHandler())
		{
			cout << "number of tasks: " << data->getPool()->getTasks().size() << endl;
		}

		//calculate cuts and add constraints
		data->getPool()->calculateCuts();
		data->getPool()->addCutConstraints(cuts, sol, &ConnectivityConstraintHandler::createConstraintCallback);

		if(data->getPool()->getNumberOfGeneratedCuts() > 0)
		{
			*result = SCIP_SEPARATED;
		}
	}
	return SCIP_OKAY;
}


//----------------------------------------
SCIP_RETCODE ConnectivityConstraintHandler::scip_sepalp(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS** conss, /**< array of constraints to
 process */
int nconss, /**< number of constraints to
 process */
int nusefulconss, /**< number of useful
 (non-obsolete) constraints to process */
SCIP_RESULT* result /**< pointer to store the
 result of the separation call */
) {
	SCIP_CALL(
			separateConnectivityInequalities(scip, conshdlr, conss, nconss, nusefulconss,
					NULL, result));
	return SCIP_OKAY;
}

//----------------------------------------
SCIP_RETCODE ConnectivityConstraintHandler::scip_sepasol(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS** conss, /**< array of constraints to
 process */
int nconss, /**< number of constraints to
 process */
int nusefulconss, /**< number of useful
 (non-obsolete) constraints to process */
SCIP_SOL* sol, /**< primal solution that
 should be separated */
SCIP_RESULT* result /**< pointer to store the
 result of the separation call */
) {
	SCIP_CALL(
			separateConnectivityInequalities(scip, conshdlr, conss, nconss, nusefulconss,
					sol, result));
	return SCIP_OKAY;
}

//----------------------------------------
SCIP_RETCODE ConnectivityConstraintHandler::scip_enfolp(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS** conss, /**< array of constraints to
 process */
int nconss, /**< number of constraints to
 process */
int nusefulconss, /**< number of useful
 (non-obsolete) constraints to process */
SCIP_Bool solinfeasible, /**< was the solution already
 declared infeasible by a constraint handler? */
SCIP_RESULT* result /**< pointer to store the
 result of the enforcing call */
) {
	*result = SCIP_FEASIBLE;
	for (int i = 0; i < nconss; ++i) {
		SCIP_CONSDATA* consdata = SCIPconsGetData(conss[i]);
		assert(consdata != NULL);
		const CVSAPData* data = consdata->data;
		assert(data != NULL);

		if (this->checkViolationOfConnectivityConstraints(scip, data, NULL)) {
			//TODO: CHECK IF OKAY!
			*result = SCIP_CUTOFF;
			break;
		}
	}

	return SCIP_OKAY;
}

//----------------------------------------
SCIP_RETCODE ConnectivityConstraintHandler::scip_enfops(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS** conss, /**< array of constraints to
 process */
int nconss, /**< number of constraints to
 process */
int nusefulconss, /**< number of useful
 (non-obsolete) constraints to process */
SCIP_Bool solinfeasible, /**< was the solution already
 declared infeasible by a constraint handler? */
SCIP_Bool objinfeasible, /**< is the solution
 infeasible anyway due to violating lower objective bound? */
SCIP_RESULT* result /**< pointer to store the
 result of the enforcing call */
) {
	*result = SCIP_FEASIBLE;

	for (int i = 0; i < nconss; ++i) {
		SCIP_CONSDATA* consdata = SCIPconsGetData(conss[i]);
		assert(consdata != NULL);
		const CVSAPData* data = consdata->data;
		assert(data != NULL);

		if (checkViolationOfConnectivityConstraints(scip, data, NULL)) {
			*result = SCIP_INFEASIBLE;
			break;
		}
	}
	return SCIP_OKAY;
}

//----------------------------------------
SCIP_RETCODE ConnectivityConstraintHandler::scip_check(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS** conss, /**< array of constraints to
 process */
int nconss, /**< number of constraints to
 process */
SCIP_SOL* sol, /**< the solution to check
 feasibility for */
SCIP_Bool checkintegrality, /**< has integrality to be
 checked? */
SCIP_Bool checklprows, /**< have current LP rows to be
 checked? */
SCIP_Bool printreason, /**< should the reason for the
 violation be printed? */
SCIP_RESULT* result /**< pointer to store the result
 of the feasibility checking call */
) {
	*result = SCIP_FEASIBLE;

	for (int i = 0; i < nconss; ++i) {
		SCIP_CONSDATA* consdata = SCIPconsGetData(conss[i]);
		assert(consdata != NULL);
		const CVSAPData* data = consdata->data;
		assert(data != NULL);

		if (checkViolationOfConnectivityConstraints(scip, data, sol)) {
			*result = SCIP_INFEASIBLE;
			if (printreason) {
				SCIP_CALL(SCIPprintCons(scip, conss[i], NULL));
				SCIPinfoMessage(scip, NULL, " Connectivity Constraint violation\n");
			}
		}
	}

	return SCIP_OKAY;
}

//----------------------------------------
SCIP_RETCODE ConnectivityConstraintHandler::scip_lock(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS* cons, /**< the constraint that
 should lock rounding of its variables, or NULL if the
 *   constraint handler does
 not need constraints */
int nlockspos, /**< no. of times, the
 roundings should be locked for the constraint */
int nlocksneg /**< no. of times, the
 roundings should be locked for the constraint's negation */
) {
	SCIP_CONSDATA* consdata;

	consdata = SCIPconsGetData(cons);
	assert(consdata != NULL);

	const CVSAPData* data = consdata->data;
	assert(data != NULL);

	for (int i = 0; i < data->graph().num_edges(); ++i) {
		SCIP_CALL(
				SCIPaddVarLocks(scip, data->arc_var(i), nlocksneg, nlockspos));
	}

	return SCIP_OKAY;
}

//----------------------------------------

SCIP_RETCODE SCIPcreateConnectivityConstraint(SCIP* scip, /**< SCIP data structure */
SCIP_CONS** cons, /**< pointer to hold the
 created constraint */
const char* name, /**< name of constraint */
CVSAPData* data, /**< the underlying graph */
SCIP_Bool initial, /**< should the LP relaxation
 of constraint be in the initial LP? */
SCIP_Bool separate, /**< should the constraint be
 separated during LP processing? */
SCIP_Bool enforce, /**< should the constraint be
 enforced during node processing? */
SCIP_Bool check, /**< should the constraint be
 checked for feasibility? */
SCIP_Bool propagate, /**< should the constraint be
 propagated during node processing? */
SCIP_Bool local, /**< is constraint only valid
 locally? */
SCIP_Bool modifiable, /**< is constraint modifiable
 (subject to column generation)? */
SCIP_Bool dynamic, /**< is constraint dynamic? */
SCIP_Bool removable /**< should the constraint be
 removed from the LP due to aging or cleanup? */
) {
	// Find the subtour constraint handler.
	SCIP_CONSHDLR* conshdlr = SCIPfindConshdlr(scip, HANDLER_NAME);
	if (conshdlr == NULL) {
		SCIPerrorMessage(HANDLER_NAME);
		SCIPerrorMessage(" not found\n");
		return SCIP_PLUGINNOTFOUND;
	}

	// Create constraint data.
	SCIP_CONSDATA* consdata = 0;
	SCIP_CALL(SCIPallocMemory(scip, &consdata));
	consdata->data = data;

	// Create constraint.
	SCIP_CALL(
			SCIPcreateCons(scip, cons, name, conshdlr, consdata, initial,
					separate, enforce, check, propagate, local, modifiable,
					dynamic, removable, FALSE));

	return SCIP_OKAY;
}

//----------------------------------------
ConnectivityConstraintHandler::ConnectivityConstraintHandler(SCIP* scip) :
		scip::ObjConshdlr(scip, HANDLER_NAME, // name
				HANDLER_DESC, // description
				1000000, // separation priority
				-2000000, // enforcing priority
				-2000000, // check priority
				1, // separation frequency
				-1, // propagation frequency (off)
				1, // eager frequency
				0, // max presolving rounds
				FALSE, FALSE, FALSE, TRUE, SCIP_PROPTIMING_BEFORELP) {
}

//----------------------------------------

ConnectivityConstraintHandler::~ConnectivityConstraintHandler() {
}

//----------------------------------------

SCIP_RETCODE ConnectivityConstraintHandler::scip_delete(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS* cons, /**< the constraint belonging
 to the constraint data */
SCIP_CONSDATA** consdata /**< pointer to the
 constraint data to free */
) {
	assert(consdata != NULL);
	SCIPfreeMemory(scip, consdata);
	return SCIP_OKAY;
}

//----------------------------------------

SCIP_RETCODE ConnectivityConstraintHandler::scip_trans(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS* sourcecons, /**< source constraint to
 transform */
SCIP_CONS** targetcons /**< pointer to store created
 target constraint */
) {
	SCIP_CONSDATA* sourcedata;
	SCIP_CONSDATA* targetdata = NULL;

	sourcedata = SCIPconsGetData(sourcecons);

	SCIP_CALL(SCIPallocMemory(scip, &targetdata));
	targetdata->data = sourcedata->data;

	/// Create target constraint.
	SCIP_CALL(
			SCIPcreateCons(scip, targetcons, SCIPconsGetName(sourcecons),
					conshdlr, targetdata, SCIPconsIsInitial(sourcecons),
					SCIPconsIsSeparated(sourcecons),
					SCIPconsIsEnforced(sourcecons),
					SCIPconsIsChecked(sourcecons),
					SCIPconsIsPropagated(sourcecons),
					SCIPconsIsLocal(sourcecons),
					SCIPconsIsModifiable(sourcecons),
					SCIPconsIsDynamic(sourcecons),
					SCIPconsIsRemovable(sourcecons),
					SCIPconsIsStickingAtNode(sourcecons)));

	return SCIP_OKAY;
}

//----------------------------------------

SCIP_RETCODE ConnectivityConstraintHandler::scip_print(SCIP* scip, /**< SCIP data structure */
SCIP_CONSHDLR* conshdlr, /**< the constraint handler
 itself */
SCIP_CONS* cons, /**< the constraint that should
 be displayed */
FILE* file /**< the text file to store the
 information into */
) {
	SCIPinfoMessage(scip, file, "some cut ... \n");

	return SCIP_OKAY;
}

