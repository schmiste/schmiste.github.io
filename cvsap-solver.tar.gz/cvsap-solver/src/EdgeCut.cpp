#include "EdgeCut.h"
#include <cassert>

EdgeCut::EdgeCut(int source_, bool isAggregationCut_)
{
	this->source = source_;
	this->aggregationCut = isAggregationCut_;
}

void EdgeCut::addEdgeToCut(int edgeId)
{
	this->edgesInCut.push_back(edgeId);
}

const vector<int>& EdgeCut::getEdgesInCut() const
{
	return this->edgesInCut;
}

int EdgeCut::getSource() const
{
	return this->source;
}

bool EdgeCut::isAggregationCut() const
{
	return this->aggregationCut;
}

void EdgeCut::reinitEdgeCut(int source_, bool isAggregationCut_)
{
	this->source = source_;
	this->aggregationCut = isAggregationCut_;
	this->edgesInCut.clear();
}
