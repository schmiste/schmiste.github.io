
#include <iostream>
#include <fstream>
#include <algorithm>

#include "ReceiverConfiguration.h"

using namespace std;
using namespace scip;

ReceiverConfiguration::ReceiverConfiguration(string name_, double cost_)
{
	this->name = name_;
	this->cost = cost_;
	this->receivers.clear();
	this->receiver_capacities.clear();
}

double ReceiverConfiguration::get_cost() const
{
	return this->cost;
}

const string& ReceiverConfiguration::get_name() const
{
	return this->name;
}

int ReceiverConfiguration::get_receiver_capacity(int receiver) const
{
	return this->receiver_capacities.at(receiver);
}

const vector<int>& ReceiverConfiguration::get_receivers() const
{
	return this->receivers;
}

void ReceiverConfiguration::add_new_receiver(int nodeId, int capacity)
{
	this->receivers.push_back(nodeId);
	this->receiver_capacities[nodeId] = capacity;
	return;
}

bool ReceiverConfiguration::contains_receiver(int nodeId) const
{
	return find(this->receivers.begin(), this->receivers.end(), nodeId) != receivers.end();
}
