#ifndef TYPES_H
#define TYPES_H

typedef enum CONNECTIVITY_HEURISTIC_TYPE {WIDEST_DFS} HeuristicConnectivityTypes;

typedef enum WIDEST_DFS_SPECIAL_STATUS {NONE, FULLY_REACHABLE, NOT_FULLY_REACHABLE} SpecialStatus;



#endif
