/**
 * @file 	CVSAPData.h
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Implementation for CVSAPData which stores all important problem and solver related informations
 */

#ifndef CVSAP_DATA_H
#define CVSAP_DATA_H

#include <vector>
#include <limits>
#include <string>
#include <map>
#include <set>

#include "objscip/objscip.h"
#include "Digraph.h"
#include "ReceiverConfiguration.h"
#include "MaxFlowThreadpool.h"
#include "Parameters.h"

class MaxFlowThreadpool;

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	Reads data files, creates the data model and stores all important data.
 */
struct CVSAPData {

	CVSAPData();

	~CVSAPData();

	/**
	 * Reads a CVSAP data file.
	 *
	 * @param filename	specifies the file to read
	 * @return	0 if no error occurred, 1 otherwise
	 */
	int read( const char* filename );

	/**
	 * 	Creates the SCIP-variables for flows, aggregation nodes and receiver configurations
	 */
	void createVariables(SCIP* scip);

	/**
	 * Includes flow preservation constraints for each node except the super sources and super sinks:
	 * \f$ \f(\deltaOut{\Eext}(v))  = \f (\deltaIn{\Eext}(v))	\quad \forall~ v \in \VG. 	\f$
	 *
	 * @param scip	The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_FlowPreservationAtNodes(SCIP* scip);

	/**
	 * Includes the constraint that the amount of outgoing flow of aggregation nodes must at least equal the activation variable:
	 * \f$ f(\deltaOut{\Enagg}(s))  \geq \xS(s) \quad \forall~ s \in \sS. 	\f$
	 *
	 * @param scip	The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_ActivatedAggregationNodesForwardFlow(SCIP* scip);

	/**
	 * Includes the constraint ensuring that the capacity from receiving nodes towards the receiver is not violated:
	 * \f$ \f{(r,\sSinkR)} \leq \cu_r \f$
	 *
	 * @param scip	The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_CapacityIsNotViolatedReceiver(SCIP* scip);

	/**
	 * Includes the constraint that the capacity of aggregation nodes is not violated:
	 * \f$ f(e) \leq \cu_s \xS_s \quad \forall~ e=(s,\sSinkS) \in \EextSm \f$
	 *
	 * @param scip	The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_CapacityIsNotViolatedAggregationNode(SCIP* scip);

	/**
	 * Includes the constraints that bounds the number of activated receiver configurations. Currently legacy code.
	 *
	 * @param scip	The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_BoundAllowedNumberOfReceiverConfiguration(SCIP* scip);

	/**
	 * Includes the constraint that bounds the cost for activated aggregated nodes from above:
	 * \f$ \sum_{s \in \sS} \cS(s) \xS(s) \leq b\f$, where b is the budget specified in
	 *
	 * @param scip	The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_BoundCostsForInstallingAggregationNodes(SCIP* scip);

	/**
	 * Includes the constraint that sets the flow from the super source towards sending nodes to 1:
	 * \f$ \f_e = \xS(s) 		 \quad \forall~ e=(\sSource, s) \in \EextSp \f$
	 *
	 * @param scip The SCIP data structure to add the constraints to.
	 */
	void includeConstraint_SetFlowFromSuperSourceToAggregationNode(SCIP* scip);


	/**
	 * @return underlying graph
	 */
	const Digraph&          graph()     const;

	/**
	 * @return sending nodes, i.e. terminals
	 */
	const std::vector<int>& get_senders() const;

	/**
	 * @return possible aggregation nodes, i.e. Steiner sites
	 */
	const std::vector<int>& get_aggregation_nodes() const;

	/**
	 * @param nodeId	id of node in underlying graph
	 * @return	cost of activating aggregation node
	 */
	double get_aggregation_installation_cost(int nodeId);

	/**
	 * @return	list of ReceiverConfigurations, should be only one
	 */
	const std::vector<ReceiverConfiguration>& getReceiverConfigurations() const;

	/**
	 * @param id	the internal number of the receiverconfiguration corresponding to its place in the vector, in which it is stored
	 * @return
	 */
	const ReceiverConfiguration & getReceiverConfiguration(int id) const;

	/**
	 * @param id	the internal number of the receiverconfiguration corresponding to its place in the vector, in which it is stored
	 * @return		the binary variable deciding whether this receiverconfiguration is active
	 */
	SCIP_VAR* get_chi_R(int id) const;

	/**
	 * @param e		the id of the edge corresponding to the numbering in the underlying graph
	 * @return		the corresponding flow variable
	 */
	SCIP_VAR* arc_var( const int e ) const;

	/**
	 * @param nodeId id of the Steiner site in the underlying graph
	 * @return	the corresponding activation variable
	 */
	SCIP_VAR*	get_chi_A(int nodeId) const;


	/**
	 * @return id of the supersink for receivers in the underlying graph
	 */
	int getSuperSinkReceiverId() const;

	/**
	 * @return id of the supersink for aggregation nodes in the underlying graph
	 */
	int getSuperSinkAggregationId() const;

	/**
	 * @return id of the supersource in the underlying graph
	 */
	int getSuperSourceId() const;

	/**
	 * @param nodeId id corresponding to a Steiner node
	 * @return	the id of the edge from this node to the aggregation sink
	 */
	int get_edge_from_aggregation_node_to_aggregation_sink(int nodeId) const;

	/**
	 * @param nodeId id corresponding to a receiver (i.e. root)
	 * @return	the id of the edge from this node to the super sink for receivers
	 */
	int getEdgeFromReceiverToReceiverSink(int nodeId) const;

	/**
	 * @param nodeId id correspinding to any node
	 * @return	true if node is aggregation node, i.e. Steiner site, otherwise false
	 */
	bool isAggregationNode(int nodeId) const;

	/**
	 * creates the ThreadPool object that is used for separating the connectivity inequalities
	 * @param scip
	 */
	void createThreadPool(SCIP* scip);

	/**
	 * @return The ThreadPool for the Separation of connectivity inequalities
	 */
	MaxFlowThreadpool* getPool();

	/**
	 * @return set of all nodes that can be receivers, i.e. roots
	 */
	const set<int>& getReceivers() const;


	/**
	 * @param node id of a node in the underlying graph that has an incoming edge from the supersource
	 * @return	id of the edge in the underlying graph from the supersource to the specified node, if no such edge exists throws an exception
	 */
	int getEdgeFromSupersourceToNode(int node) const;

	/**
	 * @param parameters	pointer to parameters passed to the solver
	 */
	void setParameters(Parameters* parameters);

	/**
	 * @return pointer to parameters passed to solver
	 */
	const Parameters* getParameters() const;

	/**
	 * @return name of the scenario
	 */
	const std::string& getScenarioName() const;

private:

	/**
	 * Maps the given variable on the given edge.
	 *
	 * @param e
	 * @param var
	 */
	void set_arc_var( const int e, SCIP_VAR* var );

	/**
	 * creates flow variables for edges
	 * @param scip
	 */
	void createArcVariables(SCIP* scip);

	/**
	 * creates binary variables deciding which aggregation nodes are enabled
	 * @param scip
	 */
	void createAggregationNodeVariables(SCIP* scip);

	/**
	 * created binary vairbales deciding which receiver configuration (which root) is active
	 * @param scip
	 */
	void createReceiverConfigurationVariables(SCIP* scip);

	/** read from the data file	 */
	int						minNumberOfReceiverConfigurations_;
	/** read from the data file	 */
	int 					maxNumberOfReceiverConfigurations_;
	/** read from the data file	 */
	double					maxAggregationNodeBugdet_;

	/** underlying graph created in the read() procedure	 */
	Digraph                	graph_;


	/** mapping of node names to ids in the underlying graph	 */
	std::map<string, int>	nodeNameToId_;

	/** list of sending nodes, i.e. terminals */
	std::vector<int>       	senders_;
	/** list of possible aggregation nodes, i.e. Steiner sites	 */
	std::vector<int>       	aggregation_nodes_;

	/** mapping of ids of Steiner sites on the corresponding activation variables */
	std::map<int, SCIP_VAR*>	chi_A;

	/** mapping of node id on edge id towards the aggregation sink */
	std::map<int, int>		edgeFromAggregationNodeToSinkAggregation;

	/** mapping of node id on edge id from super source to the given aggregation node */
	std::map<int, int>		edgeFromSuperSourceToAggregationNode;

	/** mapping of node id on edge id from super source to the given sender */
	std::map<int, int>		edgeFromSuperSourceToSender;

	/** mapping of node id on edge id from the given receiver to the super sink for receivers */
	std::map<int, int>		edgeFromReceiverNodeToSinkReceiver;

	/** costs for installing aggregation node */
	std::map<int, double>	agg_installation_costs_;

	/** capacities of aggregation nodes */
	std::map<int, double>	agg_capacities_;

	/** list of flow variables ordered in exactly the same way as the edges in the underlying graph */
	std::vector<SCIP_VAR*>	arc_vars_;

	/**	list of receiver configurations	*/
	std::vector<ReceiverConfiguration> receiver_configurations_;

	/** set of all possible receiving nodes (roots)*/
	set<int> receivingNodes;

	/** mapping from internal id for receiver configuration to its activation variable */
	std::map<int, SCIP_VAR*> 	chi_R;

	std::string scenarioName_;

	/** name of the super source */
	std::string sSourceName_;
	/** name of the aggregation sink*/
	std::string sSinkAggregationName_;
	/** name of the receiver sink*/
	std::string sSinkReceiverName_;

	/** id of the super source in the underlying graph */
	int superSourceId_;
	/** id of the super sink for aggregation nodes in the underlying graph */
	int superSinkAggregationId_;
	/** id of the super sink for receivers in the underlying graph */
	int superSinkReceiverId_;


	/** parameters read from cvsap.set file*/
	Parameters* parameters;

	/** pointer to the threadpool used for separating connectivity inequalities */
	MaxFlowThreadpool* threadpool;
};


#endif
