#include "MaxFlowWorker.h"
#include "MaxFlowThreadpool.h"
#include "EdgeCut.h"
#include "SeparationTask.h"
#include <deque>
#include <iostream>
#include <fstream>

//initializes the data structures
MaxFlowWorker::MaxFlowWorker(MaxFlowThreadpool* pool_, std::string worker_name_) :
	hasFinished(true),
	graph(pool_->getGraph()),
	data(pool_->getData()),
	capacityTimeStamp(-1)
{
	this->pool = pool_;
	this->n = pool_->getGraph().num_nodes();
	this->m = pool_->getGraph().num_edges();
	this->predecessors = vector<int>(n,-1);
	this->cap = vector<int>(m,0);
	this->flow = vector<int>(m,0);
	this->edgesWithChangedCapacities = vector<int>(0);
	this->previousCapacities = vector<int>(0);
	this->worker_name = worker_name_;
	this->currentCutIndex = -1;
}

//executes a task, stores the results internally and notifies MaxFlowThreadpool of the progress
void MaxFlowWorker::work(SeparationTask* task)
{
	//check whether our current capacity information is correct
	if(this->capacityTimeStamp != pool->getCurrentFlowIteration())
	{
		//if not, re-read capacities and re initialize data structures
		if(data->getParameters()->isDebugThreading()) cout << "new iteration for " << this->worker_name << " " << this << endl;
		this->cap.clear();
		if(data->getParameters()->isDebugThreading()) cout << "copy capacitiies" << endl;
		const vector<int>& capacities = pool->getCurrentCapacities();
		this->cap.insert(this->cap.begin(), capacities.begin(), capacities.end());
		this->currentCutIndex = -1;
		this->capacityTimeStamp = pool->getCurrentFlowIteration();
		this->edgeCuts.clear();

	}
	int totalFlow = 0;
	//calculate flows
	int addedCuts = checkFlowAndAddCutsIfNecessary(task->source, pool->getData()->getSuperSinkReceiverId(), totalFlow, task->cutoff, 0, task);
	if(addedCuts > 0)
	{
		pool->increaseGeneratedCuts(addedCuts);
	}
	//add it to the list of finished tasks
	pthread_mutex_lock(pool->getQueueMutex());
	pool->getFinishedTasks().push_back(task);
	pthread_mutex_unlock(pool->getQueueMutex());
}


EdgeCut* MaxFlowWorker::getFreshEdgeCut(int source, bool isAggregationCut)
{
	EdgeCut* ptr;
	if(currentCutIndex >= (int)(edgeCuts.size() - 1))
	{
		ptr = new EdgeCut(source, isAggregationCut);
		edgeCuts.push_back(ptr);
		++currentCutIndex;
	}
	else
	{
		++currentCutIndex;
		ptr = edgeCuts[currentCutIndex];
		ptr->reinitEdgeCut(source, isAggregationCut);
	}
	return ptr;
}

//controls the execution of the max flow separation procedure
int MaxFlowWorker::checkFlowAndAddCutsIfNecessary(int source,
								  	  int tgt,
								  	  int& totalFlow,
								  	  int cutoff,
								  	  int current_depth,
								  	  SeparationTask* task)
{
	int addedCuts = 0;
	if(current_depth == 0)
	{
		//initially we reset the flow variables
		previousCapacities.clear();
		edgesWithChangedCapacities.clear();
		totalFlow = 0;
		for (unsigned int i = 0; i < flow.size(); ++i) {
			flow[i] = 0;
		}
	}

	//perform the max flow computation
	this->max_flow(source, tgt, totalFlow, cutoff);

	if (totalFlow < cutoff) {
		//the amount of flow directed towards the target is too low
		EdgeCut* edgeCut = getFreshEdgeCut(task->source, task->isAggregationNode);
		++addedCuts;

		bool furtherNesting = current_depth < pool->getData()->getParameters()->getNestDepth();

		//if nested cuts shall be used and another nesting will be done
		for (int e = 0; e < m; ++e)
		{
			//the predecessors vector directly yields a cut
			int e_src = pool->getGraph().src_node(e);
			int e_tgt = pool->getGraph().tgt_node(e);
			if ((predecessors[e_src] >= 0)
					&& (predecessors[e_tgt] == -1
							&& (e_tgt
									!= pool->getData()->getSuperSinkAggregationId()))
			&& (flow[e] == cap[e])) {
				if(furtherNesting)
				{
					edgesWithChangedCapacities.push_back(e);
					previousCapacities.push_back(cap[e]);
					cap[e] = pool->getData()->getParameters()->getScale();
				}
				edgeCut->addEdgeToCut(e);
			}
		}
		if(furtherNesting)
		{
			//recursive call, note that totalFlow will not be reset
			addedCuts += checkFlowAndAddCutsIfNecessary(source, tgt, totalFlow, cutoff, current_depth + 1, task);
		}
	}
	if(current_depth == 0 && pool->getData()->getParameters()->getNestDepth() > 0)
	{
		//restore original capacities
		for(unsigned int i = 0; i < edgesWithChangedCapacities.size(); ++i)
		{
			cap[edgesWithChangedCapacities[i]] = previousCapacities[i];
		}
		edgesWithChangedCapacities.clear();
		previousCapacities.clear();
	}
	return addedCuts;
}

//returns the hasFinished flag
bool MaxFlowWorker::isFinished() const
{
	if(data->getParameters()->isDebugThreading()) cout << worker_name << " " << this << " will return " << this->hasFinished << ".." << endl;
	return this->hasFinished;
}

//sets hasFinished to false, is called by MaxFlowThreadpool when preparing a new computation
void MaxFlowWorker::setFinishToFalse()
{
	this->hasFinished = false;
	if(data->getParameters()->isDebugThreading()) cout << worker_name << " " << this <<  " has " << this->hasFinished << " after settingFinishToFalse" << endl;
}


int MaxFlowWorker::getNumberOfGeneratedCuts()
{
	return currentCutIndex+1;
}

const EdgeCut* MaxFlowWorker::getEdgeCut(int index) const
{
	return this->edgeCuts[index];
}

//performs the max flow computation (re)using the internal data structures
//this is edmonds karp
void   MaxFlowWorker::max_flow( const int 				 source,
								 const int               target,
								 int&                    total,
								 const int               cutoff )
{
	static bool debug = FALSE;
	bool foundPath;
	foundPath = TRUE;

	deque<int> q;
	q.clear();

	//variables for constructing paths
	int currentNode;
	int minCap;
	int edge;
	int edge_source;
	int edge_target;

	if(debug) cout << "next iteration \n";
	while(total < cutoff && foundPath)
	{
		for (unsigned int i=0; i < predecessors.size(); ++i)
		{
			predecessors[i] = -1;
		}
		q.clear();
		q.push_back(source);
		predecessors[source] = graph.num_edges();
		foundPath = FALSE;
		if(debug) cout << "search for next path\n";
		while (!q.empty())
		{
			currentNode = q.front();
			q.pop_front();
			if(debug) cout << "handle node " << graph.get_node_name(currentNode) << "\n";
			if (currentNode == target)
			{
				if(debug) cout << "path found\n";
				forwardEdges.clear();
				reverseEdges.clear();
				minCap = std::numeric_limits<int>::max();
				//look for path from s to t and calculate minimal capacity
				while ((edge = predecessors[currentNode]) != graph.num_edges())
				{
					if(debug) cout << "constructing path... \n";
					edge_source = graph.src_node(edge);
					edge_target = graph.tgt_node(edge);
					if(edge_target == currentNode)
					{
						if(debug) cout << "forward..." << edge_source << "\n";
						if(minCap > cap[edge] - flow[edge])
						{
							minCap = cap[edge] - flow[edge];
						}
						currentNode = edge_source;
						forwardEdges.push_back(edge);
					}
					else if(edge_source == currentNode)
					{
						if(debug) cout << "reverse.." << edge_target << "\n";
						if(minCap > flow[edge])
						{
							minCap = flow[edge];
						}
						currentNode = edge_target;
						reverseEdges.push_back(edge);
					}
					else
					{
						assert(0);
					}
				}
				if(debug) cout << "path construction completed; flow value: " << minCap << "\n";
				//augment flow along path
				for (unsigned int i=0; i< forwardEdges.size(); ++i)
				{
					if(debug) cout << "before augment on " << forwardEdges[i] << " (" << graph.src_node(forwardEdges[i]) << "," << graph.tgt_node(forwardEdges[i]) << "): "<< flow[forwardEdges[i]];
					flow[forwardEdges[i]] = flow[forwardEdges[i]] + minCap;
					if(debug) cout << "... after: " << flow[forwardEdges[i]] << "\n";
				}
				for (unsigned int i=0; i< reverseEdges.size(); ++i)
				{
					if(debug) cout << "before augment on " << reverseEdges[i] << " (" << graph.src_node(reverseEdges[i]) << "," << graph.tgt_node(reverseEdges[i]) << "): "<< flow[reverseEdges[i]];
					flow[reverseEdges[i]] = flow[reverseEdges[i]] - minCap;
					if(debug) cout << "... after: " << flow[reverseEdges[i]] << "\n";
				}
				if(debug) cout << "total flow: " << total << "\n";
				total += minCap;
				foundPath = TRUE;
				break;
			}
			else{
				if(debug) cout << "handle neighbors of " << graph.get_node_name(currentNode) << "\n";
				const std::vector<int>&  currentOutEdges = graph.out_edges(currentNode);
				for (unsigned int i=0; i< currentOutEdges.size(); ++i)
				{
					edge_target = graph.tgt_node(currentOutEdges[i]);
					if (predecessors[edge_target] == -1 && cap[currentOutEdges[i]] - flow[currentOutEdges[i]] > 0)
					{
						if(debug) cout << "from " << graph.get_node_name(currentNode) << "added node " << graph.get_node_name(edge_target) << " to queue as it is reachable via edge " << currentOutEdges[i] << "(" << graph.get_node_name(graph.src_node(currentOutEdges[i])) << "," << graph.get_node_name(graph.tgt_node(currentOutEdges[i])) << ") with cap " <<  cap[currentOutEdges[i]] << " and flow " << flow[currentOutEdges[i]] << "\n";
						predecessors[edge_target] = currentOutEdges[i];
						if(edge_target == target)
						{
							q.push_front(edge_target);
							break;
						}
						else
						{
							q.push_back(edge_target);
						}
					}
				}
				const std::vector<int>&  currentInEdges = graph.in_edges(currentNode);
				for (unsigned int i=0; i< currentInEdges.size(); ++i)
				{
					edge_source = graph.src_node(currentInEdges[i]);
					if (predecessors[edge_source] == -1 && flow[currentInEdges[i]] > 0)
					{
						if(debug) cout << "from " << currentNode << "added node " << edge_source << " to queue as it is reachable via edge " << currentInEdges[i] << "(" << graph.src_node(currentInEdges[i]) << "," << graph.tgt_node(currentInEdges[i]) << ") with cap " <<  cap[currentInEdges[i]] << " and flow " << flow[currentInEdges[i]] << "\n";
						predecessors[edge_source] = currentInEdges[i];
						if(edge_source == target)
						{
							q.push_front(edge_source);
							break;
						}
						else
						{
							q.push_back(edge_source);
						}

					}
				}
			}
		}
	}
}


