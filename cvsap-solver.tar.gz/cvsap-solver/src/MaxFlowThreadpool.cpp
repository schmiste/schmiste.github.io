#include <MaxFlowThreadpool.h>
#include <pthread.h>
#include <unistd.h>
#include <sstream>
#include <iostream>
#include <utility>

MaxFlowThreadpool::MaxFlowThreadpool(int numberOfThreads_, SCIP* scip_, const Digraph& g_, const CVSAPData* data_) :
	numberOfThreads(numberOfThreads_),
	scip(scip_),
	g(g_),
	data(data_),
	capacities(data_->graph().num_edges()),
	current_flow_iteration(0),
	currently_generated_cuts(0),
	threads(NULL),
	halt(false)
{
	//init the objects for synchronization
	pthread_mutex_init(&(this->queue_mutex), (pthread_mutexattr_t*)NULL);
	pthread_mutex_init(&(this->finish_barrier), (pthread_mutexattr_t*)NULL);
	pthread_mutex_init(&(this->generatedCutCounterMutex), (pthread_mutexattr_t*)NULL);
	pthread_cond_init(&(this->queue_condition), (pthread_condattr_t*)NULL);
	pthread_cond_init(&(this->finish_condition), (pthread_condattr_t*)NULL);
}


void* MaxFlowThreadpool::work(void* data)
{
	//retrieve the worker object
	MaxFlowWorker* worker = (MaxFlowWorker*) data;
	MaxFlowThreadpool* pool = worker->pool;
	bool keepGeneratingCuts = true;
	bool workersShallHalt = true;
	while(true)
	{
		SeparationTask* task;
		{   // acquire lock
			pthread_mutex_lock(pool->getQueueMutex());
			// look for a task
			std::deque<SeparationTask*>& tasks = pool->getTasks();
			while(!(workersShallHalt = pool->workersShallHalt()) && ( !(keepGeneratingCuts = pool->keepGeneratingCuts()) || tasks.size() == 0))
			{ // if there are none wait for notification
				if(pool->getData()->getParameters()->isDebugThreading()) cout << worker->worker_name << " " << worker <<  " awoke with " << worker->hasFinished << "and is going to sleep soon.." << endl;
				{
					pthread_mutex_lock(pool->getFinishMutex());
					worker->hasFinished = true;
				    pthread_cond_broadcast(pool->getFinishCondition());
				    pthread_mutex_unlock(pool->getFinishMutex());
				}
				if(pool->getData()->getParameters()->isDebugThreading()) cout << worker->worker_name << " " << worker <<  " goes to sleep with " << worker->hasFinished << endl;
			    pthread_cond_wait(pool->getQueueCondition(), pool->getQueueMutex());
			}
			if(pool->getData()->getParameters()->isDebugThreading()) cout << worker->worker_name << " " << worker <<  " awoke with " << worker->hasFinished << "and is going to work.." << endl;
			if(workersShallHalt)
				return 0;

			// get the task from the queue
			task = tasks.front();
			tasks.pop_front();
			pthread_mutex_unlock(pool->getQueueMutex());
		}
		//execute task
		worker->work(task);
	}
	return 0;
}

//creates threads that will execute the above work method
void MaxFlowThreadpool::createThreads()
{
	this->threads = new pthread_t[numberOfThreads];
	for(int i = 0; i<numberOfThreads; ++i)
	{
		stringstream ss;
		ss << i;
		std::string name = "worker_" + ss.str();
		MaxFlowWorker* worker = new MaxFlowWorker(this, name);
		workers.push_back(worker);
		pthread_create(&threads[i], (pthread_attr_t*)NULL, this->work, worker);
	}
}

MaxFlowThreadpool::~MaxFlowThreadpool()
{
    // stop all threads
    this->halt = true;
    pthread_cond_broadcast(&(this->queue_condition));

    // join them
    for(size_t i = 0;i<workers.size();++i)
    {
    	//wait for the threads to exit
        pthread_join(threads[i], (void**)NULL);
        //and delete it!
        delete workers[i];
    }
    for(unsigned int i = 0; i < finishedTasks.size(); ++i)
    {
    	delete finishedTasks[i];
    }
    pthread_cond_destroy(&finish_condition);
    pthread_cond_destroy(&queue_condition);
    pthread_mutex_destroy(&queue_mutex);
    pthread_mutex_destroy(&finish_barrier);
    pthread_mutex_destroy(&generatedCutCounterMutex);

}

std::deque<SeparationTask* >& MaxFlowThreadpool::getTasks()
{
	return this->tasks;
}

std::vector<SeparationTask* >& MaxFlowThreadpool::getFinishedTasks()
{
	return this->finishedTasks;
}

void MaxFlowThreadpool::readCapacities(SCIP_SOL* sol)
{
	//store capacity information
	for (int e = 0; e < g.num_edges(); ++e) {
		const double x = SCIPgetSolVal(scip, sol, data->arc_var(e));
		int rounded = ceil(x * data->getParameters()->getScale());
		if(rounded == 0 && data->getParameters()->isUseCreep())
		{
			rounded = 1;
		}
		this->capacities[e] = rounded;
	}
}

void MaxFlowThreadpool::calculateCuts()
{
	//prepare new flow_iteration
	this->current_flow_iteration++;
	//set finish flag of workers to false
	pthread_mutex_lock(this->getFinishMutex());
	for(unsigned int i = 0; i < workers.size(); ++i)
	{
		workers[i]->setFinishToFalse();
	}
	pthread_mutex_unlock(this->getFinishMutex());
	//acquire queue mutex and notify_all
    pthread_cond_broadcast(&(this->queue_condition));


	//wait for all tasks to have finished
	{
    	pthread_mutex_lock(&(this->finish_barrier));
		bool allFinished = false;
		while(!allFinished)
		{
			allFinished = true;
			if(this->data->getParameters()->isDebugThreading()) cout << "checking whether everybody is finished.." << endl;
			for(unsigned int i = 0; i < workers.size(); ++i)
			{
				if(!workers[i]->hasFinished)
				{
					if(this->data->getParameters()->isDebugThreading()) cout << "worker "<< workers[i]->worker_name << " " << workers[i]<< " is not finished!" << endl;
					allFinished = false;
					break;
				}
			}
			if(allFinished == false)
			{
				if(this->data->getParameters()->isDebugThreading()) cout << "going to sleep waiting for notification from threads.." << endl;
				pthread_cond_broadcast(&(this->queue_condition));
				pthread_cond_wait(&(this->finish_condition), &(this->finish_barrier));
			}
		}
		pthread_mutex_unlock(&(this->finish_barrier));
	}
}

//retrieves all generated cuts, and calls the callback function given as parameter to add the correpsonding
//inequalities to the model
SCIP_RETCODE MaxFlowThreadpool::addCutConstraints(int& cuts, SCIP_SOL* sol, SCIP_RETCODE (*callback)(SCIP* scip, SCIP_SOL* sol, const Digraph& g, const CVSAPData* data, const EdgeCut* edgeCut, int& cuts))
{
	SCIP_RETCODE result = SCIP_OKAY;
	for(unsigned int i = 0; i < workers.size(); ++i)
	{
		int numberOfGeneratedCuts = workers[i]->getNumberOfGeneratedCuts();
		for(int cut = 0; cut < numberOfGeneratedCuts; ++cut)
		{
			const EdgeCut* edgeCut = workers[i]->getEdgeCut(cut);
			SCIP_CALL(callback(this->scip, sol, this->g, this->data, edgeCut, cuts));
		}
	}
	return result;
}

int MaxFlowThreadpool::getNumberOfGeneratedCuts()
{
	return currently_generated_cuts;
}

pthread_mutex_t* MaxFlowThreadpool::getQueueMutex()
{
	return &(this->queue_mutex);
}

pthread_cond_t* MaxFlowThreadpool::getQueueCondition()
{
	return &(this->queue_condition);
}

pthread_mutex_t* MaxFlowThreadpool::getFinishMutex()
{
	return &(this->finish_barrier);
}

pthread_cond_t* MaxFlowThreadpool::getFinishCondition()
{
	return &(this->finish_condition);
}

bool MaxFlowThreadpool::workersShallHalt() const
{
	return halt;
}

int MaxFlowThreadpool::getCurrentFlowIteration() const
{
	return this->current_flow_iteration;
}

const vector<int>& MaxFlowThreadpool::getCurrentCapacities() const
{
	return this->capacities;
}

const Digraph& MaxFlowThreadpool::getGraph() const
{
	return this->g;
}


const CVSAPData* MaxFlowThreadpool::getData() const
{
	return this->data;
}

const SCIP* MaxFlowThreadpool::getScip() const
{
	return this->scip;
}

void MaxFlowThreadpool::increaseGeneratedCuts(int foundCuts)
{
	{
		pthread_mutex_lock(&(this->generatedCutCounterMutex));
		currently_generated_cuts += foundCuts;
		pthread_mutex_unlock(&(this->generatedCutCounterMutex));
	}
}

bool MaxFlowThreadpool::keepGeneratingCuts() const
{
	bool result = false;
	{
		//std::unique_lock<std::mutex> lock(this->generatedCutCounterMutex);
		result = currently_generated_cuts < data->getParameters()->getMaxCutsBeforeLpRecalculation();
	}
	return result;
}

void MaxFlowThreadpool::resetNumberOfGeneratedCuts()
{
	{
		pthread_mutex_lock(&(this->generatedCutCounterMutex));
		currently_generated_cuts = 0;
		pthread_mutex_unlock(&(this->generatedCutCounterMutex));
	}
}
