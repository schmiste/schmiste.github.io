

#ifndef EDGECUT_H
#define EDGECUT_H

#include <vector>

using namespace std;

/**
 * @author	Matthias Rost (mrost@net.t-labs.tu-berlin.de)
 * @brief	A simple data structure representing edge cuts, i.e. a set of edges. Is used during the separation procedures.
 */
class EdgeCut {

public:

	/**
	 *
	 * @param source			Node that is violated by the cut
	 * @param isAggregationCut	determines whether the node source is an aggregation node
	 */
	EdgeCut(int source, bool isAggregationCut);

	/**
	 * adds a single edge to the cut
	 * @param edgeId id of the edge in the underlying graph
	 */
	void addEdgeToCut(int edgeId);

	/**
	 * @return	all edges contained in the cut as reference (!)
	 */
	const vector<int>& getEdgesInCut() const;

	/**
	 * @return	the node which connectivity is violated by this cut
	 */
	int getSource() const;

	/**
	 * @return	determines whether the node (which connectivity is violated) is an aggregation node
	 */
	bool isAggregationCut() const;

	/**
	 * just like the constructor, but without creating a new object
	 * @param source
	 * @param isAggregationCut
	 */
	void reinitEdgeCut(int source, bool isAggregationCut);

private:
	/** edges contained in the cut*/
	vector< int > edgesInCut;
	/** source of this cut */
	int source;
	/** flag whether the source node is an aggregation node*/
	bool aggregationCut;
};








#endif
