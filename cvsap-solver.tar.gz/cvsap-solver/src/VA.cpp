
#include "VA.h"
#include <iostream>
#include <sstream>



using namespace std;


VA::VA() : root(),
			terminals(),
			steinerNodes(),
			vEdges(),
			paths()
{
}

void VA::addTerminal(int nodeId)
{
	this->terminals.insert(nodeId);
}

void VA::addSteinerNode(int nodeId)
{
	this->steinerNodes.insert(nodeId);
}

void VA::setRoot(int nodeId)
{
	this->root = nodeId;
}

void VA::addVirtualEdge(int head, int tail, const vector<int>& path)
{
	if(this->vEdges.find(head) != this->vEdges.end())
	{
		cout << "ERROR: there exists already an outgoing arc for " << head << endl;
		return;
	}
	if(this->paths.find(head) != this->paths.end())
	{
		cout << "ERROR: path for " << head << " already existed!" << endl;
		return;
	}
	this->vEdges[head] = tail;
	this->paths[head] = path;
}

void VA::cleanUp()
{
	this->terminals.clear(),
	this->steinerNodes.clear();
	this->root = -1;
	this->vEdges.clear();
	this->paths.clear();
}



